// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import $ from 'jquery'
// import 'bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.min.js'
import axios from 'axios'
import Qs from 'qs'
import HeyUI from 'heyui'
import slider from 'vue-concise-slider'// 引入slider组件
import VueAwesomeSwiper from 'vue-awesome-swiper'
import 'swiper/dist/css/swiper.css'
//QS是axios库中带的，不需要我们再npm安装一个
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import VuejsDialog from "vuejs-dialog"
import store from './store' //引入状态管理 store
 

Vue.use(VuejsDialog)
Vue.prototype.axios = axios;
Vue.prototype.qs = Qs;
Vue.config.productionTip = false
Vue.use(HeyUI);
Vue.use(VueAwesomeSwiper);
Vue.use(ElementUI)


/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>',
  render: h => h(App)
})
