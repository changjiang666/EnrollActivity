import Vue from 'vue'
import vuex from 'vuex'
Vue.use(vuex);

const state = {
    loginState: false
}

const getters = {
    getLoginState() {
        return state.loginState;
    }
}

const mutations = {
    setLoginState(state, flag) {
        state.loginState = flag;
    }
}

const actions = {
    setLoginStateAction(context, loginState) {
        context.commit('setLoginState', loginState);
    }
}

const store = new vuex.Store({
    state,
    getters,
    mutations,
    actions
})

export default store;