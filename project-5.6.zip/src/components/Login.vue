<template>

  <div class="loginWrapper">
    <el-form
      ref="AccountFrom"
      :model="account"
      :rules="rules"
      label-position="left"
      label-width="0px"
      class="demo-ruleForm login-container"
    >
      <h3 class="title">系统登录</h3>
      <el-form-item prop="username">
        <div style="display: flex">
          <div style="width: 20%">账号：</div>
          <el-input type="text" v-model="account.username" auto-complete="off" placeholder="账号"></el-input>
        </div>
      </el-form-item>

      <el-form-item prop="pwd">
        <div style="display: flex">
          <div style="width: 20%">密码：</div>
          <el-input type="password" v-model="account.pwd" auto-complete="off" placeholder="密码"></el-input>
        </div>
      </el-form-item>
      <el-checkbox v-model="checked" checked class="remember">记住密码</el-checkbox>
      <el-form-item style="width:100%;">
        <el-button type="primary" @click="loginSuccess" style="width:100%;">登录</el-button>
      </el-form-item>
    </el-form>

    <div
      class="modal fade"
      id="exampleModalLong"
      tabindex="-1"
      role="dialog"
      aria-labelledby="exampleModalLongTitle"
      aria-hidden="true"
    >
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">提示</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">账号或者密码错误</div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>



<script>
import {mapState, mapGetters, mapActions} from 'vuex';
export default {
  name: "Login",

  data() {
    return {
      logining: false,
      account: {
        username: "",
        pwd: ""
      },
      rules: {
        username: [
          { required: true, message: "请输入账号", trigger: "blur" }
          //{ validator: validaePass }
        ],
        pwd: [
          { required: true, message: "请输入密码", trigger: "blur" }
          //{ validator: validaePass2 }
        ]
      },
      checked: true
    };
  },

  methods: {
    loginSuccess: function() {
      if (this.account.username == "admin" && this.account.pwd == "123456") {
        console.log("登录成功");
        this.$store.dispatch('setLoginStateAction', true);
        this.$router.push({ path: "/Index" });
      } else {
        $("#exampleModalLong").modal();
      }
    }
  },

  mounted() {}
};
</script>




<style scoped>
body {
  background: #dfe9fb;
}
.login-container {
  width: 350px;
  margin-left: 35%;
}

.el-input {
  width: 80%;
}

.login-container[data-v-ef68022e] {
  margin-top: 9%;
}

.loginWrapper {
  background-image: url("/static/bk1.png");
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
  background-attachment: fixed;
  position: absolute;
  width: 100%;
  height: 100%;
}
</style>



