<template>
  <div class="wrapper">
    <div class="wrapper-top">
      <div class="top-left">
        <img src="\static\index\governor.png" alt="主页图片">
      </div>
      <div class="top-right">
        <h1>报名助手后台管理系统</h1>
      </div>
    </div>

    <hr>
    <div>
      <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item">
          <a
            class="nav-link active"
            id="home-tab"
            data-toggle="tab"
            href="#home"
            role="tab"
            aria-controls="home"
            aria-selected="true"
          >用户</a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link"
            id="profile-tab"
            data-toggle="tab"
            href="#profile"
            role="tab"
            aria-controls="profile"
            aria-selected="false"
          >活动</a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link"
            id="contact-tab"
            data-toggle="tab"
            href="#contact"
            role="tab"
            aria-controls="contact"
            aria-selected="false"
          >组织</a>
        </li>
      </ul>

      <!-- 用户表 -->
      <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
          <div>
            <button
              type="button"
              class="btn btn-primary"
              style="margin-left: 90%"
              @click="deleteSelect"
            >删除选中</button>
          </div>
          <div class="list-title item-title">
            <div class="item" @click="selectAll">
              <input type="checkbox" id="selectAllId">selectAll
            </div>
            <div class="item">id</div>
            <div class="item">name</div>
            <div class="item">avatarUrl</div>
            <div class="item">gender</div>
            <div class="item">age</div>
            <div class="item">phone</div>
            <div class="item">school</div>
            <div class="item">operation</div>
          </div>
          <div class="list2">
            <div>
              <div class="list-content" v-for="item in userList" v-bind:key="item.id">
                <div class="item">
                  <input
                    type="checkbox"
                    v-model="deleteList"
                    v-bind:id="item.id"
                    v-bind:value="item.id"
                  >
                </div>
                <div class="item">{{item.id}}</div>
                <div class="item">{{item.name}}</div>
                <div class="item">
                  <button @click="showImage" v-bind:data-url="item.avatarUrl">打开图片预览</button>
                </div>
                <div class="item">{{item.gender}}</div>
                <div class="item">{{item.age}}</div>
                <div class="item">{{item.phone}}</div>
                <div class="item">{{item.school}}</div>
                <div class="item item2">
                  <button
                    @click="showModal2"
                    v-bind:data-index="item.id"
                    data-type="user-activityType"
                  >活动</button>
                  <button
                    @click="showModal3"
                    v-bind:data-index="item.id"
                    data-type="user-orgType"
                  >组织</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 活动表 -->
        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
          <div>
            <button
              type="button"
              class="btn btn-primary"
              style="margin-left: 90%"
              @click="deleteSelectActivity"
            >删除选中</button>
          </div>
          <div class="list-title item3-title">
            <div class="item3" @click="selectAll2">
              <input type="checkbox" id="selectAllId2">selectAll
            </div>
            <div class="item3">id</div>
            <div class="item3">orgId</div>
            <div class="item3">imageHead</div>
            <div class="item3">type</div>
            <div class="item3">title</div>
            <div class="item3">content</div>
            <div class="item3">EndTime</div>
            <div class="item3">address</div>
            <div class="item3">PersonNum</div>
            <div class="item3">imageList</div>
            <div class="item3">phone</div>
            <div class="item3">operation</div>
          </div>
          <div class="list2">
            <div>
              <div class="list-content" v-for="item in activityList" v-bind:key="item.id">
                <div class="item3">
                  <input
                    type="checkbox"
                    v-model="deleteActivityList"
                    v-bind:id="item.id"
                    v-bind:value="item.id"
                  >
                </div>
                <div class="item3">{{item.id}}</div>
                <div class="item3">{{item.orgId}}</div>
                <div class="item3">
                  <button @click="showImage" v-bind:data-url="item.imageHead">打开图片预览</button>
                </div>
                <div class="item3">{{item.type}}</div>

                <div class="item3" style="overflow-y:hidden; white-space: nowrap">{{item.title}}</div>

                <div class="item3" style="overflow-y:hidden; white-space: nowrap">{{item.content}}</div>
                <div
                  class="item3"
                  style="overflow-y:hidden; white-space: nowrap"
                >{{item.activityEndTime}}</div>
                <div class="item3" style="overflow-y:hidden; white-space: nowrap">{{item.address}}</div>

                <div class="item3">{{item.currentPersonNum}}</div>
                <div class="item3">
                  <button @click="showAllImage" v-bind:data-url="item.imageList">打开图片预览</button>
                </div>
                <div class="item3" style="overflow-y:hidden; white-space: nowrap">{{item.phone}}</div>
                <div class="item3 item2">
                  <button
                    @click="showModal4"
                    v-bind:data-index="item.id"
                    data-type="activity-userType"
                  >用户</button>
                  <button
                    @click="showModal5"
                    v-bind:data-index="item.id"
                    data-type="activity-orgType"
                  >组织</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 组织表 -->
        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
          <div>
            <button
              type="button"
              class="btn btn-primary"
              style="margin-left: 90%"
              @click="deleteSelectOrg"
            >删除选中</button>
          </div>
          <div class="list-title item4-title">
            <div class="item4" @click="selectAll3">
              <input type="checkbox" id="selectAllId3">selectAll
            </div>
            <div class="item4">id</div>
            <div class="item4">image</div>
            <div class="item4">introduction</div>
            <div class="item4">name</div>
            <div class="item4">address</div>
            <div class="item4">phone</div>
            <div class="item4">creatorId</div>
            <div class="item4">operation</div>
          </div>
          <div class="list2">
            <div>
              <div class="list-content" v-for="item in orgList" v-bind:key="item.id">
                <div class="item4">
                  <input
                    type="checkbox"
                    v-model="deleteOrgList"
                    v-bind:id="item.id"
                    v-bind:value="item.id"
                  >
                </div>
                <div class="item4">{{item.id}}</div>
                <div class="item4">
                  <button @click="showImage" v-bind:data-url="item.image">打开图片预览</button>
                </div>
                <div
                  class="item4"
                  style="overflow-y:hidden; white-space: nowrap"
                >{{item.introduction}}</div>
                <div class="item4">{{item.name}}</div>
                <div class="item4" style="overflow-y:hidden; white-space: nowrap">{{item.address}}</div>
                <div class="item4">{{item.phone}}</div>
                <div class="item4">{{item.creatorId}}</div>
                <div class="item4 item2">
                  <button
                    @click="showModal1"
                    v-bind:data-index="item.id"
                    data-type="org-activityType"
                  >活动</button>
                  <button
                    @click="showModal6"
                    v-bind:data-index="item.id"
                    data-type="org-userType"
                  >用户</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 由用户/组织/活动跳转到其他的模态框 -->
    <div
      class="modal fade"
      id="modalType"
      tabindex="-1"
      role="dialog"
      aria-labelledby="myModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title" id="myModalLabel">详细信息</h4>
          </div>

          <div class="modal-body">
            <div>
              <div v-if="this.type == 'org-activityType'">
                <modal :list="this.orgActivityList" :type="this.type"></modal>
              </div>
              <div v-else-if="type == 'org-userType'">
                <modal
                  :orgCreatorList="this.orgCreatorList"
                  :orgEnrollUserList="this.orgEnrollUserList"
                  :orgGovernorList="this.orgGovernorList"
                  :type="this.type"
                ></modal>
              </div>
              <div v-else-if="type == 'user-activityType'">
                <modal
                  :userEnrollActivityList="this.userEnrollActivityList"
                  :userGovernActivityList="this.userGovernActivityList"
                  :userLaunchActivityList="this.userLaunchActivityList"
                  :userConcernActivityList="this.userConcernActivityList"
                  :type="this.type"
                ></modal>
              </div>
              <div v-else-if="type == 'user-orgType'">
                <modal
                  :userEnrollOrgList="this.userEnrollOrgList"
                  :userCreateOrgList="this.userEnrollOrgList"
                  :userGovernOrgList="this.userGovernOrgList"
                  :type="this.type"
                ></modal>
              </div>
              <div v-else-if="type == 'activity-userType'">
                <modal
                  :activityLaunchorList="this.activityLaunchorList"
                  :activityEnrollorList="this.activityEnrollorList"
                  :activityConcernorList="this.activityConcernorList"
                  :activityGovernorList="this.activityGovernorList"
                  :type="this.type"
                ></modal>
              </div>
              <div v-else>
                <modal :activityOrg="this.activityOrg" :type="this.type"></modal>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
          </div>
        </div>
      </div>
    </div>

    <!--预览图片模态框 -->
    <div style="z-index:3">
      <div
        class="imgModal modal fade"
        id="imageModal"
        tabindex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              图片预览
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <img style="height:300px" v-bind:src="imgUrl" alt="无法显示图片">
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal -->
    <div
      class="modal fade"
      id="exampleModalLong"
      tabindex="-1"
      role="dialog"
      aria-labelledby="exampleModalLongTitle"
      aria-hidden="true"
    >
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">预览图片</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <swiper
              :options="swiperOption"
              class="swiper-wrap"
              ref="mySwiper"
              v-if="imgList.length!=0"
            >
              <swiper-slide v-for="(item,index) in imgList" :key="index">
                <img :src="link+item" alt="无法显示图片" style="height:300px">
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
              </swiper-slide>

              <div
                class="swiper-pagination"
                v-for="(item,index) in imgList"
                :key="index"
                slot="pagination"
              ></div>
            </swiper>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>






<script>
import qs from "qs";
import Modal from "@/components/Modal";
import "swiper/dist/css/swiper.css"; //在全局没引入，这里记得要！
import { swiper, swiperSlide } from "vue-awesome-swiper";

export default {
  name: "Index",

  data() {
    return {
      link: "http://ihindy.tk:8086/EnrollAcvt/image/",
      openModal: false, //标示图片模态框的打开与关闭
      imgUrl: "", //图片的标示
      isShowImg: false, //控制图片列表的显示与关闭
      imgList: [], //存放图片地址

      userList: [],
      userEnrollActivityList: [],
      userGovernActivityList: [],
      userLaunchActivityList: [],
      userConcernActivityList: [],
      userEnrollOrgList: [],
      userGovernOrgList: [],
      userCreateOrgList: [],

      activityList: [],
      activityLaunchorList: [],
      activityEnrollorList: [],
      activityConcernorList: [],
      activityGovernorList: [],
      activityOrg: [],

      orgList: [],
      orgActivityList: [],
      orgCreatorList: [],
      orgEnrollUserList: [],
      orgGovernorList: [],

      userId: "", //点击按钮调用后台参数
      orgId: "",
      type: "", //控制子组件的显示类型
      deleteList: [], //需要删除的用户id列表
      deleteActivityList: [], //需要删除的活动id列表
      deleteOrgList: [], //需要删除的组织id列表

      swiperOption: {
        //是一个组件自有属性，如果notNextTick设置为true，组件则不会通过NextTick来实例化swiper，也就意味着你可以在第一时间获取到swiper对象，假如你需要刚加载遍使用获取swiper对象来做什么事，那么这个属性一定要是true
        // notNextTick: true,
        //循环
        loop: true,
        //设定初始化时slide的索引
        initialSlide: 0,
        // 自动播放
        autoplay: {
          delay: 1500,
          stopOnLastSlide: false,
          /* 触摸滑动后是否继续轮播 */
          disableOnInteraction: false
        },
        //滑动速度
        speed: 800,
        //滑动方向
        direction: "horizontal",
        //小手掌抓取滑动
        grabCursor: true,
        //分页器设置
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
          type: "bullets"
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev"
        }
      }
    };
  },

  methods: {
    //无条件选择所有的用户
    selectAllUser: function() {
      var that = this;
      return this.axios({
        url: "/api/selectAllUser",
        method: "post",
        data: this.qs.stringify({}),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      });
    },

    //无条件选择所有的活动
    selectAllActivity: function() {
      var that = this;
      return this.axios({
        url: "/api/selectAllActivity",
        method: "post",
        data: this.qs.stringify({}),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      });
    },

    //无条件选择所有的组织
    selectAllOrg: function() {
      var that = this;
      return this.axios({
        url: "/api/selectAllOrg",
        method: "post",
        data: this.qs.stringify({}),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      });
    },

    //根据orgId选择该组织创建的活动
    selectActivityByOrgId: function() {
      var that = this;
      return this.axios({
        url: "/api/selectActivityByOrgId",
        method: "post",
        data: this.qs.stringify({ orgId: that.orgId }),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      });
    },

    //显示由组织到活动的模态框
    showModal1: function(e) {
      var that = this;
      // console.log(e);
      this.orgId = e.target.dataset.index;
      this.type = e.target.dataset.type;
      console.log(this.type);
      this.selectActivityByOrgId().then(function(res) {
        console.log(res);
        that.orgActivityList = res.data;
        console.log(that.orgActivityList);
        $("#modalType").modal();
      });
    },

    //根据orgId选择该组织的创建者，管理者，参与者
    selectUserByOrgId: function() {
      var that = this;
      return this.axios({
        url: "/api/selectUserByOrgId",
        method: "post",
        data: this.qs.stringify({ orgId: that.orgId }),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      });
    },

    //显示由组织到用户的模态框
    showModal6: function(e) {
      var that = this;
      // console.log(e);
      this.orgId = e.target.dataset.index;
      this.type = e.target.dataset.type;
      console.log(this.type);
      this.selectUserByOrgId().then(function(res) {
        that.orgCreatorList = res.data.orgCreatorList;
        that.orgEnrollUserList = res.data.orgEnrollUserList;
        that.orgGovernorList = res.data.orgGovernorList;
        console.log(that.orgCreatorList);
        $("#modalType").modal();
      });
    },

    //根据userId选择该组织创建的活动
    selectActivityByUserId: function() {
      var that = this;
      return this.axios({
        url: "/api/selectActivityByUserId",
        method: "post",
        data: this.qs.stringify({ userId: that.userId }),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      });
    },

    //显示由用户到活动的模态框
    showModal2: function(e) {
      var that = this;
      // console.log(e);
      this.userId = e.target.dataset.index;
      this.type = e.target.dataset.type;
      console.log(this.type);
      this.selectActivityByUserId().then(function(res) {
        console.log(res);
        that.userEnrollActivityList = res.data.enrollList;
        that.userGovernActivityList = res.data.governList;
        that.userLaunchActivityList = res.data.launchList;
        that.userConcernActivityList = res.data.concernList;
        $("#modalType").modal();
      });
    },

    //根据userId选择该组织创建的活动
    selectAllOrgByUserId: function() {
      var that = this;
      return this.axios({
        url: "/api/selectAllOrgByUserId",
        method: "post",
        data: this.qs.stringify({ userId: that.userId }),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      });
    },

    //显示由用户到组织的模态框
    showModal3: function(e) {
      var that = this;
      // console.log(e);
      this.orgId = e.target.dataset.index;
      this.type = e.target.dataset.type;
      console.log(this.type);
      this.selectAllOrgByUserId().then(function(res) {
        console.log(res);
        that.userCreateOrgList = res.data.createOrg;
        that.userGovernOrgList = res.data.governOrg;
        that.userEnrollOrgList = res.data.enrollOrg;
        $("#modalType").modal();
      });
    },

    //根据activityId选择该活动的创建者，管理者，参与者，关注者
    selectAllUserByActivityId: function() {
      var that = this;
      return this.axios({
        url: "/api/selectAllUserByActivityId",
        method: "post",
        data: this.qs.stringify({ activityId: that.activityId }),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      });
    },

    //显示活动到用户的模态框
    showModal4: function(e) {
      var that = this;
      // console.log(e);
      this.activityId = e.target.dataset.index;
      this.type = e.target.dataset.type;
      console.log(this.type);
      this.selectAllUserByActivityId().then(function(res) {
        console.log(res);
        that.activityLaunchorList = res.data.activityLaunchorList;
        that.activityEnrollorList = res.data.activityEnrollorList;
        that.activityConcernorList = res.data.activityConcernorList;
        that.activityGovernorList = res.data.activityGovernorList;
        $("#modalType").modal();
      });
    },

    //根据activityId选择该活动所属的组织
    selectAllOrgByActivityId: function() {
      var that = this;
      return this.axios({
        url: "/api/selectAllOrgByActivityId",
        method: "post",
        data: this.qs.stringify({ activityId: that.activityId }),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        }
      });
    },

    //显示由用户到组织的模态框
    showModal5: function(e) {
      var that = this;
      // console.log(e);
      this.activityId = e.target.dataset.index;
      this.type = e.target.dataset.type;
      console.log(this.type);
      this.selectAllOrgByActivityId().then(function(res) {
        console.log(res);
        that.activityOrg = res.data;
        $("#modalType").modal();
      });
    },

    //用户表中的删除按钮实现
    deleteSelect2: function() {
      var that = this;
      var userIdList = JSON.stringify(that.deleteList);
      console.log(userIdList);
      return this.axios({
        url: "/api/deleteSelect",
        method: "post",
        data: this.qs.stringify({ userIdList: userIdList })
      });
    },

    deleteSelect: function() {
      var that = this;
      that.userList = [];
      this.deleteSelect2().then(function(res) {
        that.userList = res.data;
      });
    },

    //活动表中的删除按钮实现
    deleteSelectActivity2: function() {
      var that = this;
      var activityIdList = JSON.stringify(that.deleteActivityList);
      console.log(activityIdList);

      return this.axios({
        url: "/api/deleteActivityByIdList",
        method: "post",
        data: this.qs.stringify({ activityIdList: activityIdList })
      });
    },

    deleteSelectActivity: function() {
      var that = this;
      that.activityList = [];
      this.deleteSelectActivity2().then(function(res) {
        that.activityList = res.data;
      });
    },

    //组织表中的删除按钮实现
    deleteSelectOrg2: function() {
      var that = this;
      var orgIdList = JSON.stringify(that.deleteOrgList);
      console.log(orgIdList);

      return this.axios({
        url: "/api/deleteOrgByIdList",
        method: "post",
        data: this.qs.stringify({ orgIdList: orgIdList })
      });
    },

    deleteSelectOrg: function() {
      var that = this;
      that.orgList = [];
      this.deleteSelectOrg2().then(function(res) {
        that.orgList = res.data;
      });
    },

    // 用户表中删除全部的功能的实现
    selectAll: function() {
      console.log($("#selectAllId")[0].checked);
      if ($("#selectAllId")[0].checked) {
        this.deleteList = [];
        for (var i = 0; i < this.userList.length; ++i) {
          this.deleteList.push(this.userList[i].id);
        }
      }

      if ($("#selectAllId")[0].checked == false) {
        this.deleteList = [];
      }
    },

    // 活动表中删除全部的功能的实现
    selectAll2: function() {
      console.log($("#selectAllId2")[0].checked);
      if ($("#selectAllId2")[0].checked) {
        this.deleteActivityList = [];
        for (var i = 0; i < this.activityList.length; ++i) {
          this.deleteActivityList.push(this.activityList[i].id);
        }
      }

      if ($("#selectAllId2")[0].checked == false) {
        this.deleteActivityList = [];
      }
    },

    // 组织表中删除全部的功能的实现
    selectAll3: function() {
      console.log($("#selectAllId3")[0].checked);
      if ($("#selectAllId3")[0].checked) {
        this.deleteOrgList = [];
        for (var i = 0; i < this.orgList.length; ++i) {
          this.deleteOrgList.push(this.orgList[i].id);
        }
      }

      if ($("#selectAllId3")[0].checked == false) {
        this.deleteOrgList = [];
      }
    },

    // 控制图片模态框的显示
    showImage: function(e) {
      console.log(e);
      this.imgUrl = this.link + e.target.dataset.url;
      console.log(this.imgUrl);
      $("#imageModal").modal();
    },

    //控制所有图片的显示
    showAllImage: function(e) {
      this.isShowImg = !this.isShowImg;
      var image = e.target.dataset.url;
      this.imgList = image.split(" ");
      if (this.isShowImg) {
        $("#exampleModalLong").modal();
      } else {
        $("#exampleModalLong").modal("hide");
      }
    }
  },

  beforeMount() {
    console.log(this.$store.getters.getLoginState);
    if(!this.$store.getters.getLoginState) {
        this.$router.push({ path: "/" });
    }
  },

  mounted() {
    var that = this;
    that.selectAllUser().then(function(res) {
      console.log(res.data);
      that.userList = res.data.uList;
      // console.log(that.list);
    });

    that.selectAllActivity().then(function(res) {
      console.log(res.data);
      that.activityList = res.data;
    });

    that.selectAllOrg().then(function(res) {
      console.log(res.data);
      that.orgList = res.data;
    });
  },

  // 引入子组件
  components: {
    modal: Modal,
    swiper,
    swiperSlide
  }
};
</script>


<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.wrapper {
  position: absolute;
  width: 100%;
  height: 100%;
   
}

/* 第一部分的样式 */
.wrapper-top {
  position: relative;
  width: 100%;
  height: 20%;
  display: flex;
}
.top-left img {
  width: 100px;
}
.top-right {
  width: 77%;
  height: 100%;
}
.top-left {
  width: 23%;
  height: 100%;
}
.top-left img[data-v-82b7485c] {
  width: 134px;
}

/* 第二部分的样式 */
.wrapper-btn {
  position: relative;
  width: 100%;
  height: 8%;
}
.wrapper-btn button {
  font-size: 14px;
  padding: 0.5%;
  margin-left: 4%;
  margin-top: 1%;
  width: 20%;
}
.wrapper-list {
  width: 100%;
  height: 60%;
  /* background-color: blue; */
}

/* 用户表的样式 */
.list-title {
  display: flex;
}
.item-title {
  border: 1px solid black;
}
.item {
  width: 12.5%;
  /* border: 1px solid black; */
}
.list-content {
  display: flex;
}
.item2 {
  display: flex;
}
.list-content .item {
  border: 1px solid black;
}
.item2 button {
  font-size: 13px;
  padding: 0;
  height: 50%;
  margin-left: 24%;
  margin-top: 8%;
}
.list2 {
  position: absolute;
  width: 100%;
  height: 50%;
  overflow: scroll;
  /* border: 1px solid red; */
}

/* 活动表的样式 */
.list-content .item3 {
  width: 7.69%;
  border: 1px solid black;
}
.item3-title {
  border: 1px solid black;
}
.item3 {
  width: 7.56%;
}
.modal-dialog {
  max-width: 100%;
  width: 90%;
  margin: 5% auto;
}
.list-content .item2 button {
  font-size: 13px;
  padding: 0;
  height: 50%;
  margin-left: 20%;
  margin-top: 8%;
}

/* 组织表的样式 */
.item4-title {
  border: 1px solid black;
}
.item4 {
  width: 11.1%;
}
.list-content .item4 {
  border: 1px solid black;
}

.h1,
.h2,
.h3,
.h4,
.h5,
.h6,
h1,
h2,
h3,
h4,
h5,
h6 {
  margin-bottom: 4.5rem;
  font-weight: 500;
  line-height: 3.2;
}

.imgModal .modal-dialog {
  max-width: 100%;
  width: 50%;
}
.carousel {
  position: fixed;
  left: 36%;
  right: 36%;
  top: 23%;
}
</style>
