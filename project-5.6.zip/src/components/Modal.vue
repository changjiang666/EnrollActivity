<template>
  <div>
    <div v-if="type == 'user-activityType'">
      <div>
        <ul class="nav nav-tabs" id="myTab1" role="tablist">
          <li class="nav-item">
            <a
              class="nav-link active"
              id="enroll-tab"
              data-toggle="tab"
              href="#enroll"
              role="tab"
              aria-controls="enroll"
              aria-selected="true"
            >参与的活动</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              id="concern-tab"
              data-toggle="tab"
              href="#concern"
              role="tab"
              aria-controls="concern"
              aria-selected="false"
            >关注的活动</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              id="govern-tab"
              data-toggle="tab"
              href="#govern"
              role="tab"
              aria-controls="govern"
              aria-selected="false"
            >管理的活动</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              id="launch-tab"
              data-toggle="tab"
              href="#launch"
              role="tab"
              aria-controls="launch"
              aria-selected="false"
            >发起的活动</a>
          </li>
        </ul>

        <!-- 固定的表头 -->
        <div class="list-content">
          <div class="item1">id</div>
          <div class="item1">orgId</div>
          <div class="item1">type</div>
          <div class="item1">title</div>
          <div class="item1">content</div>
          <div class="item1">EndTime</div>
          <div class="item1">address</div>
          <div class="item1">PersonNum</div>
          <div class="item1">phone</div>
        </div>

        <div class="tab-content" id="myTabContent">
          <!-- 用户参与的活动 -->
          <div
            class="tab-pane fade show active"
            id="enroll"
            role="tabpanel"
            aria-labelledby="enroll-tab"
          >
            <div class="list-content" v-for="item in userEnrollActivityList" v-bind:key="item.id">
              <div class="item1">{{item.id}}</div>
              <div class="item1">{{item.orgId}}</div>
              <div class="item1">{{item.type}}</div>
              <div class="item1" style="overflow-y:hidden; white-space: nowrap">{{item.title}}</div>
              <div class="item1" style="overflow-y:hidden; white-space: nowrap">{{item.content}}</div>
              <div
                class="item1"
                style="overflow-y:hidden; white-space: nowrap"
              >{{item.activityEndTime}}</div>
              <div class="item1" style="overflow-y:hidden; white-space: nowrap">{{item.address}}</div>
              <div class="item1">{{item.currentPersonNum}}</div>
              <div class="item1" style="overflow-y:hidden; white-space: nowrap">{{item.phone}}</div>
            </div>
          </div>

          <!-- 用户关注的活动 -->
          <div
            class="tab-pane fade show"
            id="concern"
            role="tabpanel"
            aria-labelledby="concern-tab"
          >
            <div class="list-content" v-for="item in userConcernActivityList" v-bind:key="item.id">
              <div class="item1">{{item.id}}</div>
              <div class="item1">{{item.orgId}}</div>
              <div class="item1">{{item.type}}</div>
              <div class="item1" style="overflow-y:hidden; white-space: nowrap">{{item.title}}</div>
              <div class="item1" style="overflow-y:hidden; white-space: nowrap">{{item.content}}</div>
              <div
                class="item1"
                style="overflow-y:hidden; white-space: nowrap"
              >{{item.activityEndTime}}</div>
              <div class="item1" style="overflow-y:hidden; white-space: nowrap">{{item.address}}</div>
              <div class="item1">{{item.currentPersonNum}}</div>
              <div class="item1" style="overflow-y:hidden; white-space: nowrap">{{item.phone}}</div>
            </div>
          </div>

          <!-- 用户管理的活动 -->
          <div class="tab-pane fade show" id="govern" role="tabpanel" aria-labelledby="govern-tab">
            <div class="list-content" v-for="item in userGovernActivityList" v-bind:key="item.id">
              <div class="item1">{{item.id}}</div>
              <div class="item1">{{item.orgId}}</div>
              <div class="item1">{{item.type}}</div>
              <div class="item1" style="overflow-y:hidden; white-space: nowrap">{{item.title}}</div>
              <div class="item1" style="overflow-y:hidden; white-space: nowrap">{{item.content}}</div>
              <div
                class="item1"
                style="overflow-y:hidden; white-space: nowrap"
              >{{item.activityEndTime}}</div>
              <div class="item1" style="overflow-y:hidden; white-space: nowrap">{{item.address}}</div>
              <div class="item1">{{item.currentPersonNum}}</div>
              <div class="item1" style="overflow-y:hidden; white-space: nowrap">{{item.phone}}</div>
            </div>
          </div>

          <!-- 用户发起的活动 -->
          <div class="tab-pane fade show" id="launch" role="tabpanel" aria-labelledby="launch-tab">
            <div class="list-content" v-for="item in userLaunchActivityList" v-bind:key="item.id">
              <div class="item1">{{item.id}}</div>
              <div class="item1">{{item.orgId}}</div>
              <div class="item1">{{item.type}}</div>
              <div class="item1" style="overflow-y:hidden; white-space: nowrap">{{item.title}}</div>
              <div class="item1" style="overflow-y:hidden; white-space: nowrap">{{item.content}}</div>
              <div
                class="item1"
                style="overflow-y:hidden; white-space: nowrap"
              >{{item.activityEndTime}}</div>
              <div class="item1" style="overflow-y:hidden; white-space: nowrap">{{item.address}}</div>
              <div class="item1">{{item.currentPersonNum}}</div>
              <div class="item1" style="overflow-y:hidden; white-space: nowrap">{{item.phone}}</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div v-else-if="type == 'user-orgType'">
      <div>
        <ul class="nav nav-tabs" id="myTab1" role="tablist">
          <li class="nav-item">
            <a
              class="nav-link active"
              id="userEnrollOrg-tab"
              data-toggle="tab"
              href="#userEnrollOrg"
              role="tab"
              aria-controls="userEnrollOrg"
              aria-selected="true"
            >参与的组织</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              id="userGovernOrg-tab"
              data-toggle="tab"
              href="#userGovernOrg"
              role="tab"
              aria-controls="userGovernOrg"
              aria-selected="false"
            >管理的组织</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              id="userCreateOrg-tab"
              data-toggle="tab"
              href="#userCreateOrg"
              role="tab"
              aria-controls="userCreateOrg"
              aria-selected="false"
            >发起的组织</a>
          </li>
        </ul>

        <!-- 固定的表头 -->
        <div class="list-content">
          <div class="item2">id</div>
          <div class="item2">introduction</div>
          <div class="item2">name</div>
          <div class="item2">address</div>
          <div class="item2">phone</div>
          <div class="item2">creatorId</div>
        </div>

        <div class="tab-content" id="myTabContent">
          <!-- 用户参与的组织 -->
          <div
            class="tab-pane fade show active"
            id="userEnrollOrg"
            role="tabpanel"
            aria-labelledby="userEnrollOrg-tab"
          >
            <div class="list-content" v-for="item in userEnrollOrgList" v-bind:key="item.id">
              <div class="item2">{{item.id}}</div>
              <div class="item2">{{item.introduction}}</div>
              <div class="item2">{{item.name}}</div>
              <div class="item2" style="overflow-y:hidden; white-space: nowrap">{{item.address}}</div>
              <div class="item2" style="overflow-y:hidden; white-space: nowrap">{{item.phone}}</div>
              <div class="item2" style="overflow-y:hidden; white-space: nowrap">{{item.creatorId}}</div>
            </div>
          </div>

          <!-- 用户管理的组织 -->
          <div
            class="tab-pane fade show"
            id="userGovernOrg"
            role="tabpanel"
            aria-labelledby="userGovernOrg-tab"
          >
            <div class="list-content" v-for="item in userGovernOrgList" v-bind:key="item.id">
              <div class="item2">{{item.id}}</div>
              <div class="item2">{{item.introduction}}</div>
              <div class="item2">{{item.name}}</div>
              <div class="item2" style="overflow-y:hidden; white-space: nowrap">{{item.address}}</div>
              <div class="item2" style="overflow-y:hidden; white-space: nowrap">{{item.phone}}</div>
              <div class="item2" style="overflow-y:hidden; white-space: nowrap">{{item.creatorId}}</div>
            </div>
          </div>

          <!-- 用户发起的组织 -->
          <div
            class="tab-pane fade show"
            id="userCreateOrg"
            role="tabpanel"
            aria-labelledby="userCreateOrg-tab"
          >
            <div class="list-content" v-for="item in userCreateOrgList" v-bind:key="item.id">
              <div class="item2">{{item.id}}</div>
              <div class="item2">{{item.introduction}}</div>
              <div class="item2">{{item.name}}</div>
              <div class="item2" style="overflow-y:hidden; white-space: nowrap">{{item.address}}</div>
              <div class="item2" style="overflow-y:hidden; white-space: nowrap">{{item.phone}}</div>
              <div class="item2" style="overflow-y:hidden; white-space: nowrap">{{item.creatorId}}</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div v-else-if="type == 'org-activityType'">
      <div class="list-title">
        <div class="item" style="max-width: 5%">id</div>
        <div class="item" style="max-width: 5%">orgId</div>
        <div class="item">type</div>
        <div class="item">content</div>
        <div class="item">address</div>
        <div class="item">school</div>
        <div class="item">currentNum</div>
        <div class="item">phone</div>
      </div>
      <div class="list-content" v-for="item in list" v-bind:key="item.id">
        <div class="item" style="max-width: 5%">{{item.id}}</div>
        <div class="item" style="max-width: 5%">{{item.orgId}}</div>
        <div class="item">{{item.type}}</div>
        <div class="item" style="overflow-y:hidden; white-space: nowrap">{{item.content}}</div>
        <div class="item" style="overflow-y:hidden; white-space: nowrap">{{item.address}}</div>
        <div class="item" style="overflow-y:hidden; white-space: nowrap">{{item.school}}</div>
        <div class="item">{{item.currentPersonNum}}</div>
        <div class="item">{{item.phone}}</div>
      </div>
    </div>

    <div v-else-if="type == 'org-userType'">
      <div>
        <ul class="nav nav-tabs" id="myTab1" role="tablist">
          <li class="nav-item">
            <a
              class="nav-link active"
              id="creator-tab"
              data-toggle="tab"
              href="#creator"
              role="tab"
              aria-controls="creator"
              aria-selected="true"
            >创建者</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              id="governor-tab"
              data-toggle="tab"
              href="#governor"
              role="tab"
              aria-controls="governor"
              aria-selected="false"
            >管理者</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              id="enroller-tab"
              data-toggle="tab"
              href="#enroller"
              role="tab"
              aria-controls="enroller"
              aria-selected="false"
            >参与者</a>
          </li>
        </ul>

        <!-- 固定的表头 -->
        <div class="list-content">
          <div class="item2">id</div>
          <div class="item2">name</div>
          <div class="item2">gender</div>
          <div class="item2">age</div>
          <div class="item2">phone</div>
          <div class="item2">school</div>
        </div>

        <div class="tab-content" id="myTabContent">
          <!-- 创建者 -->
          <div
            class="tab-pane fade show active"
            id="creator"
            role="tabpanel"
            aria-labelledby="creator-tab"
          >
            <div class="list-content" v-for="item in orgCreatorList" v-bind:key="item.id">
              <div class="item2">{{item.id}}</div>
              <div class="item2">{{item.name}}</div>
              <div class="item2">{{item.gender}}</div>
              <div class="item2">{{item.age}}</div>
              <div class="item2">{{item.phone}}</div>
              <div class="item2">{{item.school}}</div>
            </div>
          </div>

          <!-- 管理者 -->
          <div
            class="tab-pane fade show"
            id="governor"
            role="tabpanel"
            aria-labelledby="governor-tab"
          >
            <div class="list-content" v-for="item in orgGovernorList" v-bind:key="item.id">
              <div class="item2">{{item.id}}</div>
              <div class="item2">{{item.name}}</div>
              <div class="item2">{{item.gender}}</div>
              <div class="item2">{{item.age}}</div>
              <div class="item2">{{item.phone}}</div>
              <div class="item2">{{item.school}}</div>
            </div>
          </div>

          <!-- 参与者 -->
          <div
            class="tab-pane fade show"
            id="enrollor"
            role="tabpanel"
            aria-labelledby="enrollor-tab"
          >
            <div class="list-content" v-for="item in orgEnrollUserList" v-bind:key="item.id">
              <div class="item2">{{item.id}}</div>
              <div class="item2">{{item.name}}</div>
              <div class="item2">{{item.gender}}</div>
              <div class="item2">{{item.age}}</div>
              <div class="item2">{{item.phone}}</div>
              <div class="item2">{{item.school}}</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div v-else-if="type == 'activity-userType'">
      <div>
        <ul class="nav nav-tabs" id="myTab1" role="tablist">
          <li class="nav-item">
            <a
              class="nav-link active"
              id="activityEnrollor-tab"
              data-toggle="tab"
              href="#activityEnrollor"
              role="tab"
              aria-controls="activityEnrollor"
              aria-selected="true"
            >参与者</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              id="activityConcernor"
              data-toggle="tab"
              href="#activityConcernor"
              role="tab"
              aria-controls="activityConcernor"
              aria-selected="false"
            >关注者</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              id="activityGovernor-tab"
              data-toggle="tab"
              href="#activityGovernor"
              role="tab"
              aria-controls="activityGovernor"
              aria-selected="false"
            >管理者</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              id="activityLaunchor-tab"
              data-toggle="tab"
              href="#activityLaunchor"
              role="tab"
              aria-controls="activityLaunchor"
              aria-selected="false"
            >发起者</a>
          </li>
        </ul>

        <!-- 固定的表头 -->
        <div class="list-content">
          <div class="item2">id</div>
          <div class="item2">name</div>
          <div class="item2">gender</div>
          <div class="item2">age</div>
          <div class="item2">phone</div>
          <div class="item2">school</div>
        </div>

        <div class="tab-content" id="myTabContent">
          <!-- 参与者 -->
          <div
            class="tab-pane fade show active"
            id="activityEnrollor"
            role="tabpanel"
            aria-labelledby="activityEnrollor-tab"
          >
            <div class="list-content" v-for="item in activityEnrollorList" v-bind:key="item.id">
              <div class="item2">{{item.id}}</div>
              <div class="item2">{{item.name}}</div>
              <div class="item2">{{item.gender}}</div>
              <div class="item2">{{item.age}}</div>
              <div class="item2">{{item.phone}}</div>
              <div class="item2">{{item.school}}</div>
            </div>
          </div>

          <!-- 关注者 -->
          <div
            class="tab-pane fade show"
            id="activityConcernor"
            role="tabpanel"
            aria-labelledby="activityConcernor-tab"
          >
            <div class="list-content" v-for="item in activityConcernorList" v-bind:key="item.id">
              <div class="item2">{{item.id}}</div>
              <div class="item2">{{item.name}}</div>
              <div class="item2">{{item.gender}}</div>
              <div class="item2">{{item.age}}</div>
              <div class="item2">{{item.phone}}</div>
              <div class="item2">{{item.school}}</div>
            </div>
          </div>

          <!-- 管理者 -->
          <div
            class="tab-pane fade show"
            id="activityGovernor"
            role="tabpanel"
            aria-labelledby="activityGovernor-tab"
          >
            <div class="list-content" v-for="item in activityGovernorList" v-bind:key="item.id">
              <div class="item2">{{item.id}}</div>
              <div class="item2">{{item.name}}</div>
              <div class="item2">{{item.gender}}</div>
              <div class="item2">{{item.age}}</div>
              <div class="item2">{{item.phone}}</div>
              <div class="item2">{{item.school}}</div>
            </div>
          </div>

          <!-- 发起者 -->
          <div
            class="tab-pane fade show"
            id="activityLaunchor"
            role="tabpanel"
            aria-labelledby="activityLaunchor-tab"
          >
            <div class="list-content" v-for="item in activityLaunchorList" v-bind:key="item.id">
              <div class="item2">{{item.id}}</div>
              <div class="item2">{{item.name}}</div>
              <div class="item2">{{item.gender}}</div>
              <div class="item2">{{item.age}}</div>
              <div class="item2">{{item.phone}}</div>
              <div class="item2">{{item.school}}</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div v-else>
      <div class="list-content">
        <div class="item2">id</div>
        <div class="item2">introduction</div>
        <div class="item2">name</div>
        <div class="item2">address</div>
        <div class="item2">phone</div>
        <div class="item2">creatorId</div>
      </div>
      <div class="list-content" v-for="item in activityOrg" v-bind:key="item.id">
        <div class="item2">{{item.id}}</div>
        <div class="item2">{{item.introduction}}</div>
        <div class="item2">{{item.name}}</div>
        <div class="item2" style="overflow-y:hidden; white-space: nowrap">{{item.address}}</div>
        <div class="item2" style="overflow-y:hidden; white-space: nowrap">{{item.phone}}</div>
        <div class="item2" style="overflow-y:hidden; white-space: nowrap">{{item.creatorId}}</div>
      </div>
    </div>
  </div>
</template>
 
 <script>
export default {
  props: {
    // 接受组织传过来的活动参数
    list: {
      type: Array,
      default: () => {
        return [];
      }
    },

    //接受组织传过来的用户参数
    orgCreatorList: {
      type: Array,
      default: () => {
        return [];
      }
    },

    orgEnrollUserList: {
      type: Array,
      default: () => {
        return [];
      }
    },

    orgGovernorList: {
      type: Array,
      default: () => {
        return [];
      }
    },
    //接受用户传过来的活动参数
    userEnrollActivityList: {
      type: Array,
      default: () => {
        return [];
      }
    },

    userGovernActivityList: {
      type: Array,
      default: () => {
        return [];
      }
    },

    userLaunchActivityList: {
      type: Array,
      default: () => {
        return [];
      }
    },

    userConcernActivityList: {
      type: Array,
      default: () => {
        return [];
      }
    },

    // 接受用户传过来的组织参数
    userEnrollOrgList: {
      type: Array,
      default: () => {
        return [];
      }
    },

    userGovernOrgList: {
      type: Array,
      default: () => {
        return [];
      }
    },

    userCreateOrgList: {
      type: Array,
      default: () => {
        return [];
      }
    },

    //接受活动传到用户的参数
    activityLaunchorList: {
      type: Array,
      default: () => {
        return [];
      }
    },

    activityEnrollorList: {
      type: Array,
      default: () => {
        return [];
      }
    },

    activityConcernorList: {
      type: Array,
      default: () => {
        return [];
      }
    },

    activityGovernorList: {
      type: Array,
      default: () => {
        return [];
      }
    },

    //接受活动传到组织的参数
    activityOrg: {
      type: Array,
      default: () => {
        return [];
      }
    },

    type: {
      type: String,
      default: () => {
        return "";
      }
    }
  }
};
</script>
 
 <style scoped>
.item {
  width: 13.3%;
  border: 1px solid black;
}
.list-content {
  display: flex;
}
.list-title {
  display: flex;
}
.list1 {
  position: absolute;
  width: 100%;
  height: 50%;
  overflow: scroll;
}

.item1 {
  width: 11.1%;
  border: 1px solid black;
}

.item2 {
  width: 16.6%;
  border: 1px solid black;
}
</style>
 
