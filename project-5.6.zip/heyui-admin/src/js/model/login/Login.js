export default new Model({
  username: '',
  password: ''
});
