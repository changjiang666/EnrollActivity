export default new Model({
  int: null,
  number: null,
  url: null,
  email: null,
  tel: null,
  mobile: null,
  input: '',
  textarea: '测试',
  radio: 1,
  rate: null,
  checkbox: [1],
  select1: '人民币',
  select2: '',
  select3: [],
  taginputs: [],
  autocomplete: null,
  money: {
    min: null,
    max: null
  },
  date: null,
  inputs: [],
  things: ['']
})
;