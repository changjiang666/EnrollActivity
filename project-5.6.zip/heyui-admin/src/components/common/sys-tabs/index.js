import SysTabs from './sys-tabs';

export default SysTabs;
