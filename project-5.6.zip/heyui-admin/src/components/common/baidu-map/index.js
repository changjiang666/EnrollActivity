import BaiduMap from './baidu-map';

export default BaiduMap;
