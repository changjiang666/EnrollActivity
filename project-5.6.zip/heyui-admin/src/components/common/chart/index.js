import ECharts from './echarts';

require('echarts/lib/component/tooltip');

export default ECharts;
