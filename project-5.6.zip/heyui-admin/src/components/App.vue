<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>
<script>

import store from 'js/vuex/store';

export default {
  data() {
    return {
    };
  },
  store,
  mounted() {
  },
  methods: {
  }
};
</script>
