module.exports = {
  presets: [
    ['@vue/app', { modules: false }]
  ],
  sourceType: 'unambiguous'
};
