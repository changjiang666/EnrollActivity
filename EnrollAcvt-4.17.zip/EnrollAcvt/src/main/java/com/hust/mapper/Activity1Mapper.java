package com.hust.mapper;

import com.hust.bean.Activity1;
import com.hust.bean.Activity2;

import java.util.List;

public interface Activity1Mapper {

    //userId -> enrollActivityId -> activity1
    List<Activity1> selectEnrollActivity(int id);

    //activityId list -> activity1 list
    List<Activity1> selectActivityListByIdList(List<Integer> activityIdList);

    // insert activity1
    void insertActivity1(Activity1 activity1);

    //activityId -> activity1
    Activity1 selectActivityById(int activityId);

    //activityId -> activity2
    void insertActivity2(Activity2 activity2);

    int getActivityId();

    void updateActivity1(Activity1 activity1);

    void updateActivity2(Activity2 activity2);

    void deleteActivity1(int activityId);

    void deleteActivity2(int activityId);

    List<Activity1> getAll();
}
