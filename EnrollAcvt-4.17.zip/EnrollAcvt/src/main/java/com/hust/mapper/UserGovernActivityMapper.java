package com.hust.mapper;

import com.hust.bean.UserGovernActivity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserGovernActivityMapper {

    public UserGovernActivity selectByUserIdAndActivityId(@Param("userId") int userId, @Param("activityId") int activityId);

    public void insertUserGovernActivityById(@Param("userId") int userId, @Param("activityId") int activityId);

    public void deleteUserGovernActivityById(@Param("userId") int userId, @Param("activityId") int activityId);

    public List<Integer> selectUserGovernActivityByUserId(int userId);

    public List<Integer> selectUserGovernActivityByActivityId(int activityId);

    public void deleteRecordByActivityId(int activityId);
}
