package com.hust.mapper;

import com.hust.bean.Organization;

public interface OrganizationMapper {

    Organization selectOrgById(int orgId);
}
