package com.hust.service;


import com.hust.bean.UserGovernActivity;
import com.hust.mapper.UserGovernActivityMapper;
import com.hust.utilis.GetApplicationContext;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("userGovernActivityService")
public class UserGovernActivityService {

    private static ApplicationContext ac;
    static  {
        ac = GetApplicationContext.getInstance();
    }

    public void insertUserGovernActivityById(int userId, int activityId) {

        UserGovernActivityMapper mapper = ac.getBean(UserGovernActivityMapper.class);
        mapper.insertUserGovernActivityById(userId, activityId);
    }


    public void deleteUserGovernActivityById(int userId, int activityId) {

        UserGovernActivityMapper mapper = ac.getBean(UserGovernActivityMapper.class);
        mapper.deleteUserGovernActivityById(userId, activityId);
    }

    public List<Integer> selectUserGovernActivityByUserId(int userId) {

        UserGovernActivityMapper mapper = ac.getBean(UserGovernActivityMapper.class);
        return mapper.selectUserGovernActivityByUserId(userId);
    }

    public List<Integer> selectUserGovernActivityByActivityId(int activityId) {

        UserGovernActivityMapper mapper = ac.getBean(UserGovernActivityMapper.class);
        return mapper.selectUserGovernActivityByActivityId(activityId);
    }

    public void deleteRecordByActivityId(int activityId) {

        UserGovernActivityMapper mapper = ac.getBean(UserGovernActivityMapper.class);
        mapper.deleteRecordByActivityId(activityId);
    }
}
