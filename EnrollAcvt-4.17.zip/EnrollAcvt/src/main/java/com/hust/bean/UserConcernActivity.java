package com.hust.bean;


import org.springframework.stereotype.Component;

/*DROP TABLE IF EXISTS `tbl_userConcernActity`;
        CREATE TABLE `tbl_userConcernActity` (
        `id` int(11) NOT NULL,
        `userId` int(11) NOT NULL,
        `concernActityId` int(11) NOT NULL,
        PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;*/
@Component("userConcernActivity")
public class UserConcernActivity {



    private int id;
    private int useId;
    private int concernActityId;

    public UserConcernActivity() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public int getUseId() {
        return useId;
    }

    public void setUseId(int useId) {
        this.useId = useId;
    }

    public int getConcernActityId() {
        return concernActityId;
    }

    public void setConcernActityId(int concernActityId) {
        this.concernActityId = concernActityId;
    }

    @Override
    public String toString() {
        return "UserConcernActivity{" +
                "id=" + id +
                ", useId=" + useId +
                ", concernActityId=" + concernActityId +
                '}';
    }
}
