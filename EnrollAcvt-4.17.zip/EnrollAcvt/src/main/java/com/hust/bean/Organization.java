package com.hust.bean;

import org.springframework.stereotype.Component;


/*DROP TABLE IF EXISTS `tbl_org`;
        CREATE TABLE `tbl_org` (
        `id` int(11) NOT NULL,
        `image` varchar(255) DEFAULT NULL,
        `introduction` varchar(255) DEFAULT NULL,
        `name` varchar(255) DEFAULT NULL,
        `address` varchar(255) NOT NULL,
        `phone` varchar(255) NOT NULL,
        `creatorId` int(11) NOT NULL,
        PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;*/

@Component("organization")
public class Organization {

    private String image;
    private String introduction;
    private String name;
    private String address;
    private String phone;
    private String creatorId;

    public Organization() {
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(String creatorId) {
        this.creatorId = creatorId;
    }


}
