package com.hust.controller;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.hust.bean.User;
import com.hust.service.UserService;
import com.hust.utilis.CommonUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class UserController {

    private static final String APPID = "wx59a539d568342578";
    private static final String SECRET = "7e60798093488c30eb6010330f8f3903";
    private WebApplicationContext wac;

    @RequestMapping(value="/insertUser")
    @ResponseBody
    public int insertUser(HttpServletRequest req, HttpServletResponse response) {
        Map<String, Object> map = new HashMap<String, Object>();
        String status = "1";
        String msg = "ok";
        //String code = request.getParameter("code");
        String code = "021vEpk9136ZON11Mul91UlJk91vEpkb";
        String requestUrl = "https://api.weixin.qq.com/sns/jscode2session?appid=" + APPID + "&secret=" + SECRET + "&js_code=" + code + "&grant_type=authorization_code";
        try {
            if (code == null) {
                status = "0";//失败状态
                msg = "code为空";
            } else {
                JSONObject jsonObject = CommonUtil.httpsRequest(requestUrl, "POST", null);
                if (jsonObject != null) {
                    try {
                        map.put("openid", jsonObject.getString("openid"));
                        map.put("session_key", jsonObject.getString("session_key"));
                    } catch (JSONException e) {
                        // 获取token失败
                        status = "0";
                        msg = "code无效";
                    }
                } else {
                    status = "0";
                    msg = "code无效";
                }
            }
            map.put("status", status);
            map.put("msg", msg);
        } catch (Exception e) {
        }
        //Object openid = map.get("openid");


        /*
        String name = req.getParameter("nickname");
        String avatarUrl = req.getParameter("avatarUrl");
        String gender = req.getParameter("gender");*/
        String name = "liucj";
        String openid = "huakodhuasihjidsahivo";
        String gender = "F";
        String avatarUrl = "hhhhhhhh";
        User user = new User();
        user.setName(name);
        user.setOpenid(openid.toString());
        user.setGender(gender);
        user.setAvatarUrl(avatarUrl);


        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserService userService = wac.getBean(UserService.class);
        int n = userService.insertUser(user);
        System.out.println(n);
        return n;
    }

    @RequestMapping(value="/updateUser")
    @ResponseBody
    //int id, String phone, String school, int age, String gander
    public void updateUser(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserService userService = wac.getBean(UserService.class);

        User user = new User();

        /*int id = Integer.valueOf(req.getParameter("id"));
        String school = req.getParameter("school");
        int age = Integer.valueOf(req.getParameter("age"));
        String phone = req.getParameter("phone");
        String gender = req.getParameter("gender");*/


        int id = 1;
        String school = "hust";
        int age = 20;
        String phone = "123456787654";
        String gender = "M";

        user.setSchool(school);
        user.setGender(gender);
        user.setAge(age);
        user.setId(id);
        user.setPhone(phone);
        userService.updateUser(user);

    }

    @RequestMapping(value="/selectUserById")
    @ResponseBody
    //List<int> id, bool hasGender, bool hasAvatraUrl, bool hasAge, bool hasPhone, bool hasSchool
    public Map<String, Object> selectUserById(HttpServletRequest req, HttpServletResponse response
            /*,@RequestParam("id") List<Integer> idList*/) {

        List<Integer> idList = new ArrayList<Integer>();
        idList.add(1);
        idList.add(2);

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserService userService = wac.getBean(UserService.class);

        Map<String, Object> ans = new HashMap<String, Object>();
        List<User> uList = new ArrayList<User>();

        for(Integer id :idList) {
            User user = userService.selectUserById(id);
            user.setOpenid(null);
            user.setName(null);
            uList.add(user);
        }
        ans.put("uList",uList);

        System.out.println(ans);
        return ans;
    }
}

