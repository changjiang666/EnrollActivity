package com.hust.controller;

import com.hust.bean.Activity1;
import com.hust.service.Activity1Service;
import com.hust.service.UserEnrollActivityService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
public class UserEnrollActivityController {

    private WebApplicationContext wac;

    @RequestMapping("InsertUserEnrollActivity")
    @ResponseBody
    public void InsertUserEnrollActivity(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserEnrollActivityService userEnrollActivityService = wac.getBean(UserEnrollActivityService.class);
        //int userId = Integer.valueOf(req.getParameter("userId"));
        //int activityId = Integer.valueOf(req.getParameter("activityId"));
        int userId = 2;
        int activityId = 2;
        userEnrollActivityService.InsertUserEnrollActivity(userId, activityId);
    }


    @RequestMapping("deleteUserEnrollActivity")
    @ResponseBody
    public void deleteUserEnrollActivity(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserEnrollActivityService userEnrollActivityService = wac.getBean(UserEnrollActivityService.class);
        //int userId = Integer.valueOf(req.getParameter("userId"));
        //int activityId = Integer.valueOf(req.getParameter("activityId"));
        int userId = 2;
        int activityId = 2;
        userEnrollActivityService.deleteUserEnrollActivity(userId, activityId);
    }


    @RequestMapping("selectUserEnrollActivityByUserId")
    @ResponseBody
    public List<Activity1> selectUserEnrollActivityByUserId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserEnrollActivityService userEnrollActivityService = wac.getBean(UserEnrollActivityService.class);
        //int userId = Integer.valueOf(req.getParameter("userId"));
        int userId = 1;
        List<Integer> activityIdList = userEnrollActivityService.selectUserEnrollActivityByUserId(userId);

        Activity1Service activity1Service = wac.getBean(Activity1Service.class);
        return activity1Service.selectActivityListByIdList(activityIdList);
    }

    @RequestMapping("deleteCommentById")
    @ResponseBody
    public void deleteCommentById(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserEnrollActivityService userEnrollActivityService = wac.getBean(UserEnrollActivityService.class);
        //int userId = Integer.valueOf(req.getParameter("userId"));
        //int activityId = Integer.valueOf(req.getParameter("activityId"));
        int userId = 1;
        int activityId = 2;

        userEnrollActivityService.deleteCommentById(userId, activityId);
    }
}
