package com.hust.controller;

import com.hust.bean.Organization;
import com.hust.service.OrganizationService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class OrganizationController {

    private WebApplicationContext wac;

    @RequestMapping("/selectOrgById")
    @ResponseBody
    public Organization selectOrgById(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        OrganizationService organizationService = wac.getBean(OrganizationService.class);

        //int orgId = Integer.valueOf(req.getParameter("orgId"));
        int orgId = 1;
        return organizationService.selectOrgById(orgId);
    }

}
