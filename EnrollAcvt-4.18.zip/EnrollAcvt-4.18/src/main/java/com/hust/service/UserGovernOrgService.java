package com.hust.service;

import com.hust.bean.UserGovernOrg;
import com.hust.mapper.UserGovernOrgMapper;
import com.hust.utilis.GetApplicationContext;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("userGovernOrgService")
public class UserGovernOrgService {

    private static ApplicationContext ac;
    static  {
        ac = GetApplicationContext.getInstance();
    }

    public List<Integer> selectUserGovernOrgByUserId(int userId) {

        UserGovernOrgMapper userGovernOrgMapper = ac.getBean(UserGovernOrgMapper.class);
        return userGovernOrgMapper.selectUserGovernOrgByUserId(userId);
    }

    public List<Integer> selectUserGovernOrgByOrgId(int orgId) {

        UserGovernOrgMapper userGovernOrgMapper = ac.getBean(UserGovernOrgMapper.class);
        return userGovernOrgMapper.selectUserGovernOrgByOrgId(orgId);
    }

    public void insertUserGovernOrg(int userId, int orgId) {

        UserGovernOrgMapper userGovernOrgMapper = ac.getBean(UserGovernOrgMapper.class);
        userGovernOrgMapper.insertUserGovernOrg(userId, orgId);
    }

    public void deleteUserGovernOrg(int userId, int orgId) {

        UserGovernOrgMapper userGovernOrgMapper = ac.getBean(UserGovernOrgMapper.class);
        userGovernOrgMapper.deleteUserGovernOrg(userId, orgId);
    }
}
