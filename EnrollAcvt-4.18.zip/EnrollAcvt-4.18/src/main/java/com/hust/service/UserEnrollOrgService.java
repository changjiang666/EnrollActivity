package com.hust.service;

import com.hust.mapper.UserEnrollOrgMapper;
import com.hust.utilis.GetApplicationContext;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("userEnrollOrgService")
public class UserEnrollOrgService {

    private static ApplicationContext ac;
    static  {
        ac = GetApplicationContext.getInstance();
    }

    public List<Integer> selectOrgIdByUserId(int userId) {

        UserEnrollOrgMapper userEnrollOrgMapper = ac.getBean(UserEnrollOrgMapper.class);
        return userEnrollOrgMapper.selectOrgIdByUserId(userId);
    }

    public List<Integer> selectUserEnrollOrgByOrgId(int orgId) {

        UserEnrollOrgMapper userEnrollOrgMapper = ac.getBean(UserEnrollOrgMapper.class);
        return userEnrollOrgMapper.selectUserEnrollOrgByOrgId(orgId);
    }

    public void deleteUserEnrollOrg(int userId, int orgId) {

        UserEnrollOrgMapper userEnrollOrgMapper = ac.getBean(UserEnrollOrgMapper.class);
        userEnrollOrgMapper.deleteUserEnrollOrg(userId, orgId);
    }

    public void insertUserEnrollOrg(int userId, int orgId) {

        UserEnrollOrgMapper userEnrollOrgMapper = ac.getBean(UserEnrollOrgMapper.class);
        userEnrollOrgMapper.insertUserEnrollOrg(userId, orgId);
    }
}
