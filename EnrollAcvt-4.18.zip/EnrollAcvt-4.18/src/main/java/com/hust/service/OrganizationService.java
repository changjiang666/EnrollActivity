package com.hust.service;

import com.hust.bean.Organization;
import com.hust.mapper.OrganizationMapper;
import com.hust.utilis.GetApplicationContext;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.List;


@Component("organizationService")
public class OrganizationService {

    private static ApplicationContext ac;
    static  {
        ac = GetApplicationContext.getInstance();
    }

    public Organization selectOrgById(int orgId) {
        OrganizationMapper mapper = ac.getBean(OrganizationMapper.class);
        return mapper.selectOrgById(orgId);
    }

    public int isCreator(int userId, int orgId) {

        OrganizationMapper mapper = ac.getBean(OrganizationMapper.class);
        Organization organization = mapper.selectOrgById(orgId);
        int ans = 0;
        if(organization.getCreatorId() == userId)
            ans = 1;
        return ans;
    }

    public void updateOrg(Organization organization) {

        OrganizationMapper mapper = ac.getBean(OrganizationMapper.class);
        mapper.updateOrg(organization);
    }

    public void updateCreator(int creatorId, int orgId) {

        OrganizationMapper mapper = ac.getBean(OrganizationMapper.class);
        mapper.updateCreator(creatorId, orgId);
    }

    public List<Organization> selectOrgByCreatorId(int creatorId) {

        OrganizationMapper mapper = ac.getBean(OrganizationMapper.class);
        return mapper.selectOrgByCreatorId(creatorId);
    }

    public List<Organization> selectOrgByIdList(List<Integer> orgIdList) {

        OrganizationMapper mapper = ac.getBean(OrganizationMapper.class);
        return mapper.selectOrgByIdList(orgIdList);
    }
}
