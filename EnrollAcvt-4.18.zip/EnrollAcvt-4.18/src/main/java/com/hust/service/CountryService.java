package com.hust.service;

import com.hust.bean.Country;
import com.hust.mapper.CountryMapper;
import com.hust.utilis.GetApplicationContext;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component("countryService")
public class CountryService {

    private static ApplicationContext ac;
    static  {
        ac = GetApplicationContext.getInstance();
    }

    public Map<String, Object> selectAll() {
        CountryMapper mapper = ac.getBean(CountryMapper.class);
        List<Country> list = mapper.selectAll();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("countryList", list);
        return map;
    }
}
