package com.hust.service;


import com.hust.bean.Activity1;
import com.hust.bean.User;
import com.hust.mapper.UserMapper;
import com.hust.utilis.GetApplicationContext;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("userService")
public class UserService {

    private static ApplicationContext ac;

    static {
        ac = GetApplicationContext.getInstance();
    }

    public int insertUser(User user) {
        UserMapper mapper = ac.getBean(UserMapper.class);
        mapper.insertUser(user);
        return mapper.selectUserByOpenId(user);
    }

    public void updateUser(User user) {
        UserMapper mapper = ac.getBean(UserMapper.class);
        mapper.updateUser(user);
    }

    public User selectUserById(Integer id) {

        UserMapper mapper = ac.getBean(UserMapper.class);
        return mapper.selectUserById(id);
    }

    public List<User> selectUserByIdList(List<Integer> userIdList) {

        UserMapper mapper = ac.getBean(UserMapper.class);
        List<User> userList = mapper.selectUserByIdList(userIdList);
        for(User user:userList) {
            user.setOpenid(null);
        }
        return userList;
    }
}
