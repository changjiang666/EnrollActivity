package com.hust.utilis;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class GetApplicationContext {

    private GetApplicationContext() {
    }

    private static ApplicationContext ac = null;

    // 静态代码块
    static {
        ac = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
    }

    public static ApplicationContext getInstance() {
        if (ac == null) {
            ac = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
        }
        return ac;
    }
}
