package com.hust.bean;


import org.springframework.stereotype.Component;


/*DROP TABLE IF EXISTS `tbl_userGovernOrg`;
        CREATE TABLE `tbl_userGovernOrg` (
        `id` int(11) NOT NULL,
        `userId` int(11) NOT NULL,
        `governOrgId` int(11) NOT NULL,
        PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;*/
@Component("userGovernOrg")
public class UserGovernOrg {

    private int id;
    private int userId;
    private int igovernOrgId;

    public UserGovernOrg() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getIgovernOrgId() {
        return igovernOrgId;
    }

    public void setIgovernOrgId(int igovernOrgId) {
        this.igovernOrgId = igovernOrgId;
    }

    @Override
    public String toString() {
        return "UserGovernOrg{" +
                "id=" + id +
                ", userId=" + userId +
                ", igovernOrgId=" + igovernOrgId +
                '}';
    }
}
