package com.hust.bean;

/*DROP TABLE IF EXISTS `tbl_activity2`;
        CREATE TABLE `tbl_activity2` (
        `id` int(11) NOT NULL,
        `isName` enum('1','2','3') NOT NULL,
        `isGender` enum('1','2','3') NOT NULL,
        `isAge` enum('1','2','3') NOT NULL,
        `isPhone` enum('1','2','3') NOT NULL,
        `isCorporation` enum('1','2','3') NOT NULL,
        `personLimit` int(11) NOT NULL,
        PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;*/

public class Activity2 {

    private int id;
    private int isName;
    private int isGender;
    private int isAge;
    private int isPhone;
    private int isCorporation;
    private int personLimit;

    public Activity2() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIsName() {
        return isName;
    }

    public void setIsName(int isName) {
        this.isName = isName;
    }

    public int getIsGender() {
        return isGender;
    }

    public void setIsGender(int isGender) {
        this.isGender = isGender;
    }

    public int getIsAge() {
        return isAge;
    }

    public void setIsAge(int isAge) {
        this.isAge = isAge;
    }

    public int getIsPhone() {
        return isPhone;
    }

    public void setIsPhone(int isPhone) {
        this.isPhone = isPhone;
    }

    public int getIsCorporation() {
        return isCorporation;
    }

    public void setIsCorporation(int isCorporation) {
        this.isCorporation = isCorporation;
    }

    public int getPersonLimit() {
        return personLimit;
    }

    public void setPersonLimit(int personLimit) {
        this.personLimit = personLimit;
    }

    @Override
    public String toString() {
        return "Activity2{" +
                "id=" + id +
                ", isName=" + isName +
                ", isGender=" + isGender +
                ", isAge=" + isAge +
                ", isPhone=" + isPhone +
                ", isCorporation=" + isCorporation +
                ", personLimit=" + personLimit +
                '}';
    }
}
