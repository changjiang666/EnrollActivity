package com.hust.bean;

import org.springframework.stereotype.Component;

import java.util.Date;

/*
DROP TABLE IF EXISTS `tbl_activity1`;
        CREATE TABLE `tbl_activity1` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `orgId` int(11) NOT NULL,
        `imageHead` varchar(255) NOT NULL,
        `type` varchar(255) NOT NULL,
        `title` varchar(255) NOT NULL,
        `content` varchar(255) NOT NULL,
        `avtivityStartTime` datetime NOT NULL,
        `activityEndTime` datetime NOT NULL,
        `enrollEndTime` datetime NOT NULL,
        `addressImage` varchar(255) NOT NULL,
        `address` varchar(255) NOT NULL,
        `longitude` double NOT NULL,
        `latitude` double NOT NULL,
        `activityKey` varchar(255) NOT NULL,
        `currentPersonNum` int(11) NOT NULL,
        PRIMARY KEY (`id`)
        ) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
*/
@Component("activity1")
public class Activity1 {

    private int id;
    private int orgId;
    private String imageHead;
    private String type;
    private String title;
    private String content;
    private String avtivityStartTime;
    private String activityEndTime;
    private String enrollEndTime;
    private String address;
    private String longitude;
    private String latitude;
    private String activityKey;
    private int currentPersonNum;

    public Activity1() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getOrgId() {
        return orgId;
    }

    public void setOrgId(int orgId) {
        this.orgId = orgId;
    }

    public String getImageHead() {
        return imageHead;
    }

    public void setImageHead(String imageHead) {
        this.imageHead = imageHead;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAvtivityStartTime() {
        return avtivityStartTime;
    }

    public void setAvtivityStartTime(String avtivityStartTime) {
        this.avtivityStartTime = avtivityStartTime;
    }

    public String getActivityEndTime() {
        return activityEndTime;
    }

    public void setActivityEndTime(String activityEndTime) {
        this.activityEndTime = activityEndTime;
    }

    public String getEnrollEndTime() {
        return enrollEndTime;
    }

    public void setEnrollEndTime(String enrollEndTime) {
        this.enrollEndTime = enrollEndTime;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getActivityKey() {
        return activityKey;
    }

    public void setActivityKey(String activityKey) {
        this.activityKey = activityKey;
    }

    public int getCurrentPersonNum() {
        return currentPersonNum;
    }

    public void setCurrentPersonNum(int currentPersonNum) {
        this.currentPersonNum = currentPersonNum;
    }

    @Override
    public String toString() {
        return "Activity1{" +
                "id=" + id +
                ", orgId=" + orgId +
                ", imageHead='" + imageHead + '\'' +
                ", type='" + type + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", avtivityStartTime='" + avtivityStartTime + '\'' +
                ", activityEndTime='" + activityEndTime + '\'' +
                ", enrollEndTime='" + enrollEndTime + '\'' +
                ", address='" + address + '\'' +
                ", longitude='" + longitude + '\'' +
                ", latitude='" + latitude + '\'' +
                ", activityKey='" + activityKey + '\'' +
                ", currentPersonNum=" + currentPersonNum +
                '}';
    }
}
