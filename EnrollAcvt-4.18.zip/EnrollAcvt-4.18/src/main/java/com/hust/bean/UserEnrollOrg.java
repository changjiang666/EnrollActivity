package com.hust.bean;

import org.springframework.stereotype.Component;


/*DROP TABLE IF EXISTS `tbl_userEnrollOrg`;
        CREATE TABLE `tbl_userEnrollOrg` (
        `id` int(11) NOT NULL,
        `userId` int(11) NOT NULL,
        `enrollOrgId` int(11) NOT NULL,
        PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;*/

@Component("userEnrollOrg")
public class UserEnrollOrg {

    private int id;
    private int userId;
    private int enrollOrgId;

    public UserEnrollOrg() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getEnrollOrgId() {
        return enrollOrgId;
    }

    public void setEnrollOrgId(int enrollOrgId) {
        this.enrollOrgId = enrollOrgId;
    }

    @Override
    public String toString() {
        return "UserEnrollOrg{" +
                "id=" + id +
                ", userId=" + userId +
                ", enrollOrgId=" + enrollOrgId +
                '}';
    }
}
