package com.hust.controller;

import com.hust.bean.Organization;
import com.hust.service.OrganizationService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
public class OrganizationController {

    private WebApplicationContext wac;

    @RequestMapping("/selectOrgById")
    @ResponseBody
    public Organization selectOrgById(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        OrganizationService organizationService = wac.getBean(OrganizationService.class);

        //int orgId = Integer.valueOf(req.getParameter("orgId"));
        int orgId = 1;
        return organizationService.selectOrgById(orgId);
    }


    @RequestMapping("/isCreator")
    @ResponseBody
    public int isCreator(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        OrganizationService organizationService = wac.getBean(OrganizationService.class);

        //int orgId = Integer.valueOf(req.getParameter("orgId"));
        //int userId = Integer.valueOf(req.getParameter("userId"));
        int orgId = 1;
        int userId = 1;
        return organizationService.isCreator(userId, orgId);
    }


    @RequestMapping("/updateOrg")
    @ResponseBody
    public void updateOrg(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        OrganizationService organizationService = wac.getBean(OrganizationService.class);

        /*int id = Integer.valueOf(req.getParameter("id"));
        String image = req.getParameter("image");
        String introduction = req.getParameter("introduction");
        String name = req.getParameter("name");
        String address = req.getParameter("address");
        String phone = req.getParameter("phone");*/

        int id = 1;
        String image = "hello";
        String introduction = "hello";
        String name = "hello";
        String address = "hello";
        String phone = "hello";

        Organization organization = new Organization();
        organization.setId(id);
        organization.setAddress(address);
        organization.setImage(image);
        organization.setIntroduction(introduction);
        organization.setName(name);
        organization.setPhone(phone);

        organizationService.updateOrg(organization);
    }

    @RequestMapping("/updateCreator")
    @ResponseBody
    public void updateCreator(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        OrganizationService organizationService = wac.getBean(OrganizationService.class);

        //int orgId = Integer.valueOf(req.getParameter("orgId"));
        //int creatorId = Integer.valueOf(req.getParameter("userId"));
        int orgId = 1;
        int creatorId = 2;
        organizationService.updateCreator(creatorId, orgId);
    }

    @RequestMapping("/selectOrgByCreatorId")
    @ResponseBody
    public List<Organization> selectOrgByCreatorId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        OrganizationService organizationService = wac.getBean(OrganizationService.class);

        //int creatorId = Integer.valueOf(req.getParameter("userId"));
        int creatorId = 1;
        return organizationService.selectOrgByCreatorId(creatorId);
    }

}
