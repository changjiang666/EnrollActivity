package com.hust.controller;


import com.hust.bean.Activity1;
import com.hust.bean.User;
import com.hust.service.Activity1Service;
import com.hust.service.UserGovernActivityService;
import com.hust.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
public class UserGovernActivityController {

    private WebApplicationContext wac;

    @RequestMapping("/insertUserGovernActivityById")
    @ResponseBody
    public void insertUserGovernActivityById(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserGovernActivityService userGovernActivityService = wac.getBean(UserGovernActivityService.class);

        /*int userId = Integer.valueOf(req.getParameter("userId"));
        int activityId = Integer.valueOf(req.getParameter("activityId"));*/

        int userId = 1;
        int activityId = 1;

        userGovernActivityService.insertUserGovernActivityById(userId, activityId);
    }

    @RequestMapping("/deleteUserGovernActivityById")
    @ResponseBody
    public void deleteUserGovernActivityById(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserGovernActivityService userGovernActivityService = wac.getBean(UserGovernActivityService.class);

        /*int userId = Integer.valueOf(req.getParameter("userId"));
        int activityId = Integer.valueOf(req.getParameter("activityId"));*/

        int userId = 1;
        int activityId = 1;

        userGovernActivityService.deleteUserGovernActivityById(userId, activityId);
    }

    @RequestMapping("selectUserGovernActivityByUserId")
    @ResponseBody
    public List<Activity1> selectUserGovernActivityByUserId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserGovernActivityService userGovernActivityService = wac.getBean(UserGovernActivityService.class);
        //int userId = Integer.valueOf(req.getParameter("userId"));
        int userId = 1;
        List<Integer> activityIdList = userGovernActivityService.selectUserGovernActivityByUserId(userId);

        /*List<Integer> activityIdList = new ArrayList<Integer>();
        activityIdList.add(1);
        activityIdList.add(2);
        activityIdList.add(8);*/
        Activity1Service activity1Service =wac.getBean(Activity1Service.class);
        return activity1Service.selectActivityListByIdList(activityIdList);
    }


    @RequestMapping("selectUserGovernActivityByActivityId")
    @ResponseBody
    public List<User> selectUserGovernActivityByActivityId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserGovernActivityService userGovernActivityService = wac.getBean(UserGovernActivityService.class);
        //int activityId = Integer.valueOf(req.getParameter("activityId"));
        int activityId = 1;
        List<Integer> userIdList = userGovernActivityService.selectUserGovernActivityByActivityId(activityId);

        UserService userService = wac.getBean(UserService.class);
        List<User> userList =  userService.selectUserByIdList(userIdList);
        for(User u:userList) {
            u.setOpenid(null);
        }
        return userList;
    }
}
