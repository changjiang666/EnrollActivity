package com.hust.controller;


import com.hust.bean.Organization;
import com.hust.bean.User;
import com.hust.bean.UserGovernOrg;
import com.hust.service.OrganizationService;
import com.hust.service.UserGovernOrgService;
import com.hust.service.UserService;
import org.omg.PortableInterceptor.INACTIVE;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.persistence.criteria.CriteriaBuilder;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
public class UserGovernOrgController {

    private WebApplicationContext wac;

    @RequestMapping("/selectUserGovernOrgByUserId")
    @ResponseBody
    public List<Organization> selectUserGovernOrgByUserId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserGovernOrgService userGovernOrgService = wac.getBean(UserGovernOrgService.class);
        //int userId = Integer.valueOf(req.getParameter("userId"));
        int userId = 1;
        List<Integer> orgIdList = userGovernOrgService.selectUserGovernOrgByUserId(userId);

        OrganizationService organizationService = wac.getBean(OrganizationService.class);
        return organizationService.selectOrgByIdList(orgIdList);
    }


    @RequestMapping("/selectUserGovernOrgByOrgId")
    @ResponseBody
    public List<User> selectUserGovernOrgByOrgId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserGovernOrgService userGovernOrgService = wac.getBean(UserGovernOrgService.class);
        //int orgId = Integer.valueOf(req.getParameter("orgId"));
        int orgId = 1;
        List<Integer> userIdList = userGovernOrgService.selectUserGovernOrgByOrgId(orgId);

        UserService userService = wac.getBean(UserService.class);
        return userService.selectUserByIdList(userIdList);

    }


    @RequestMapping("/insertUserGovernOrg")
    @ResponseBody
    public void insertUserGovernOrg(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserGovernOrgService userGovernOrgService = wac.getBean(UserGovernOrgService.class);
        //int orgId = Integer.valueOf(req.getParameter("orgId"));
        //int userId = Integer.valueOf(req.getParameter("userId"));
        int orgId = 1;
        int userId = 4;
        userGovernOrgService.insertUserGovernOrg(userId, orgId);
    }

    @RequestMapping("/deleteUserGovernOrg")
    @ResponseBody
    public void deleteUserGovernOrg(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserGovernOrgService userGovernOrgService = wac.getBean(UserGovernOrgService.class);
        //int orgId = Integer.valueOf(req.getParameter("orgId"));
        //int userId = Integer.valueOf(req.getParameter("userId"));
        int orgId = 1;
        int userId = 4;
        userGovernOrgService.deleteUserGovernOrg(userId, orgId);
    }

}
