package com.hust.controller;


import com.hust.bean.Organization;
import com.hust.bean.User;
import com.hust.service.OrganizationService;
import com.hust.service.UserEnrollOrgService;
import com.hust.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
public class UserEnrollOrgController {

    private WebApplicationContext wac;

    @RequestMapping("/selectOrgByUserId")
    @ResponseBody
    public List<Organization> selectOrgByUserId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserEnrollOrgService userEnrollOrgService = wac.getBean(UserEnrollOrgService.class);

        //int userId = Integer.valueOf(req.getParameter("userId"));
        int userId = 1;
        List<Integer> orgIdList = userEnrollOrgService.selectOrgIdByUserId(userId);

        OrganizationService organizationService = wac.getBean(OrganizationService.class);
        return organizationService.selectOrgByIdList(orgIdList);
    }


    @RequestMapping("/selectUserEnrollOrgByOrgId")
    @ResponseBody
    public List<User> selectUserEnrollOrgByOrgId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserEnrollOrgService userEnrollOrgService = wac.getBean(UserEnrollOrgService.class);

        //int orgId = Integer.valueOf(req.getParameter("orgId"));
        int orgId = 1;
        List<Integer> userIdList = userEnrollOrgService.selectUserEnrollOrgByOrgId(orgId);

        UserService userService = wac.getBean(UserService.class);
        return userService.selectUserByIdList(userIdList);
    }


    @RequestMapping("/deleteUserEnrollOrg")
    @ResponseBody
    public void deleteUserEnrollOrg(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserEnrollOrgService userEnrollOrgService = wac.getBean(UserEnrollOrgService.class);

        //int orgId = Integer.valueOf(req.getParameter("orgId"));
        //int userId = Integer.valueOf(req.getParameter("userId"));
        int orgId = 1;
        int userId = 1;
        userEnrollOrgService.deleteUserEnrollOrg(userId, orgId);
    }


    @RequestMapping("/insertUserEnrollOrg")
    @ResponseBody
    public void insertUserEnrollOrg(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserEnrollOrgService userEnrollOrgService = wac.getBean(UserEnrollOrgService.class);

        //int orgId = Integer.valueOf(req.getParameter("orgId"));
        //int userId = Integer.valueOf(req.getParameter("userId"));
        int orgId = 3;
        int userId = 3;
        userEnrollOrgService.insertUserEnrollOrg(userId, orgId);
    }

}
