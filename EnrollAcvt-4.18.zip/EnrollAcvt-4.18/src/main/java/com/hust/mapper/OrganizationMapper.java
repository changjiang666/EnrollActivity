package com.hust.mapper;

import com.hust.bean.Organization;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrganizationMapper {

    Organization selectOrgById(int orgId);

    void updateOrg(Organization organization);

    void updateCreator(@Param("creatorId") int creatorId, @Param("orgId") int orgId);

    List<Organization> selectOrgByCreatorId(int creatorId);

    List<Organization> selectOrgByIdList(List<Integer> orgIdList);
}
