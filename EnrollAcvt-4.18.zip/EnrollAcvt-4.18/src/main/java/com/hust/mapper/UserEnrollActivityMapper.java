package com.hust.mapper;

import com.hust.bean.UserEnrollActivity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserEnrollActivityMapper {

    //userId + activityId -> comment
    String selectActivityCommentById(@Param("userId") int userId, @Param("activityId") int activityId);

    //activityId -> List<Integer> userId
    List<Integer> selectUserIdByActivityId(int activityId);

    //userId + activityId -> isEnroll
    UserEnrollActivity selectByUserIdAndActivityId(@Param("userId") int userId, @Param("activityId") int activityId);

    void deleteRecordByActivityId(int activityId);

    void InsertUserEnrollActivity(@Param("userId") int userId, @Param("activityId") int activityId);

    void deleteUserEnrollActivity(@Param("userId") int userId, @Param("activityId") int activityId);

    List<Integer> selectUserEnrollActivityByUserId(int userId);

    void deleteCommentById(@Param("userId") int userId, @Param("activityId") int activityId);
}
