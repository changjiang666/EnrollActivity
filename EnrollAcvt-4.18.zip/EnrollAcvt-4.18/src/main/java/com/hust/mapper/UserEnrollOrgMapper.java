package com.hust.mapper;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserEnrollOrgMapper {

    List<Integer> selectOrgIdByUserId(int userId);

    List<Integer> selectUserEnrollOrgByOrgId(int orgId);

    void deleteUserEnrollOrg(@Param("userId") int userId, @Param("orgId") int orgId);

    void insertUserEnrollOrg(@Param("userId") int userId, @Param("orgId") int orgId);
}
