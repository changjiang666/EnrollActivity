package com.hust.mapper;

import com.hust.bean.UserLaunchActivity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserLaunchActivityMapper {

    UserLaunchActivity selectByUserIdAndActivityId(@Param("userId") int userId, @Param("activityId")int activityId);

    void userLaunchActivityMapper(@Param("userId") int userId, @Param("activityId")int activityId);

    int selectActivityIdByUserID(int userId);

    void deleteRecordByActivityId(int activityId);

    List<Integer> selectUserLaunchActivityById(int userId);
}
