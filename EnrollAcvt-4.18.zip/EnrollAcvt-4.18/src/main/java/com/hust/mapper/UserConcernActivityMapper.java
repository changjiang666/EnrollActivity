package com.hust.mapper;

import com.hust.bean.UserConcernActivity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserConcernActivityMapper {

    public int countAll(int activityId);

    public UserConcernActivity selectByUserIdAndActivityID(@Param("userId") int userId, @Param("activityId") int activityId);

    public void insertUserConcernActivity(@Param("userId") int userId, @Param("activityId") int activityId);

    public void delectUserConcernActivity(@Param("userId") int userId, @Param("activityId") int activityId);

    public List<Integer> selectUserConcernActivity(int userId);

    public void deleteRecordByActivityId(int activityId);
}
