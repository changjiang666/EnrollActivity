import com.hust.bean.Country;
import com.hust.mapper.CountryMapper;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.List;

public class TestTes {

    @Test
    public void test1() {

        ApplicationContext ac = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
        CountryMapper mapper = ac.getBean(CountryMapper.class);
        List<Country> countryList = mapper.selectAll();
        for(Country country : countryList) {
            System.out.println(country.toString());
        }
    }
}
