package com.hust.controller;

import com.hust.bean.Activity1;
import com.hust.service.Activity1Service;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.persistence.criteria.CriteriaBuilder;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.Map;

@Controller
public class Activity1Controller {

    private WebApplicationContext wac;

    /*@RequestMapping("/")
    public void func(HttpServletRequest req, HttpServletResponse response) {
    }*/

    @RequestMapping("/selectEnrollActivity")
    @ResponseBody
    public Map<String, Object> selectEnrollActivity(HttpServletRequest req, HttpServletResponse response) {
        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        Activity1Service activity1Service = wac.getBean(Activity1Service.class);
        //int id = Integer.valueOf(req.getParameter("id"));
        Map<String, Object> map = activity1Service.selectEnrollActivity(1);
        System.out.println(map.toString());
        return map;
    }

    @RequestMapping("/insertActivity")
    @ResponseBody
    public void insertActivity(HttpServletRequest req, HttpServletResponse response) {
        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        Activity1Service activity1Service = wac.getBean(Activity1Service.class);

        /*int id = Integer.valueOf(req.getParameter("id"));
        int creatorId = Integer.valueOf(req.getParameter("creatorId"));
        int orgId = Integer.valueOf(req.getParameter("orgId"));
        String imageHead = req.getParameter("imageHead");
        String type = req.getParameter("type");
        String title = req.getParameter("title");
        String content = req.getParameter("content");
        String avtivityStartTime = req.getParameter("avtivityStartTime");
        String activityEndTime = req.getParameter("activityEndTime");
        String enrollEndTime = req.getParameter("enrollEndTime");
        String address = req.getParameter("address");
        String longitude = req.getParameter("longitude");
        String latitude = req.getParameter("latitude");
        String activityKey = req.getParameter("activityKey");
        int currentPersonNum = Integer.valueOf("currentPersonNum");*/


        int creatorId = 2;
        int orgId = 2;
        String imageHead = "http://www.ihidny,tk";
        String type = "音乐";
        String title = "listen to music";
        String content = "欢乐音乐行";
        String avtivityStartTime = "2019-04-12 14:56:31.0";
        String activityEndTime = "2019-04-12 14:56:31.0";
        String enrollEndTime = "2019-04-12 14:56:31.0";
        String address = "华中科技大学";
        String addressImage = "http://hhhhh";
        String longitude = "12.11234";
        String latitude = "23.45465";
        String activityKey = "hello";
        int currentPersonNum = 3;
        Activity1 activity1 = new Activity1();
        activity1.setCreatorId(creatorId);
        activity1.setOrgId(orgId);
        activity1.setImageHead(imageHead);
        activity1.setType(type);
        activity1.setTitle(title);
        activity1.setContent(content);
        activity1.setActivityEndTime(activityEndTime);
        activity1.setAvtivityStartTime(avtivityStartTime);
        activity1.setEnrollEndTime(enrollEndTime);
        activity1.setAddressImage(addressImage);
        activity1.setAddress(address);
        activity1.setLatitude(latitude);
        activity1.setLongitude(longitude);
        activity1.setActivityKey(activityKey);

        activity1Service.insertActivity(activity1);
    }

    @RequestMapping("/selectAllById")
    @ResponseBody
    public Map<String, Object> selectAllById(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        Activity1Service activity1Service = wac.getBean(Activity1Service.class);
        /*int userId = Integer.valueOf(req.getParameter("userId"));
        int activityId  = Integer.valueOf(req.getParameter("activityId"));*/
        int userId = 1;
        int activityId = 2;
        Map<String, Object> map =  activity1Service.selectAllById(userId, activityId);
        System.out.println(map);
        return map;
    }
}
