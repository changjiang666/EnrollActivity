package com.hust.mapper;

import com.hust.bean.UserEnrollActivity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserEnrollActivityMapper {

    //userId + activityId -> comment
    public String selectActivityCommentById(@Param("userId") int userId, @Param("activityId") int activityId);

    //activityId -> List<Integer> userId
    public List<Integer> selectUserIdByActivityId(int activityId);

    //userId + activityId -> isEnroll
    public UserEnrollActivity selectByUserIdAndActivityId(@Param("userId") int userId, @Param("activityId") int activityId);

}
