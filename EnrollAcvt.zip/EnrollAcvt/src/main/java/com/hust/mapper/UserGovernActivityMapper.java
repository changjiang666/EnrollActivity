package com.hust.mapper;

import com.hust.bean.UserGovernActivity;
import org.apache.ibatis.annotations.Param;

public interface UserGovernActivityMapper {

    public UserGovernActivity selectByUserIdAndActivityId(@Param("userId") int userId, @Param("activityId") int activityId);
}
