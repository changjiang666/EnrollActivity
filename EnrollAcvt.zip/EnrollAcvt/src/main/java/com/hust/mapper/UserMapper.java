package com.hust.mapper;

import com.hust.bean.User;

public interface UserMapper {

    public void insertUser(User user);
    public int selectUserByOpenId(User user);

    public void updateUser(User user);

    public User selectUserById(Integer id);
}
