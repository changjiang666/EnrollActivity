package com.hust.mapper;

import com.hust.bean.UserConcernActivity;
import org.apache.ibatis.annotations.Param;

public interface UserConcernActivityMapper {

    public int countAll(int activityId);

    public UserConcernActivity selectByUserIdAndActivityID(@Param("userId") int userId, @Param("activityId") int activityId);
}
