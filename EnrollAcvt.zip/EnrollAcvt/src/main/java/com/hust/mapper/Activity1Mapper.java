package com.hust.mapper;

import com.hust.bean.Activity1;

import java.util.List;

public interface Activity1Mapper {

    //选择用户参加的所有活动
    public List<Activity1> selectEnrollActivity(int id);

    public void insertActivity(Activity1 activity1);

    public Activity1 selectActivityById(int activityId);
}
