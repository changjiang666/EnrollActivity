package com.hust.mapper;

import com.hust.bean.UserLaunchActivity;
import org.apache.ibatis.annotations.Param;

public interface UserLaunchActivityMapper {

    public UserLaunchActivity selectByUserIdAndActivityId(@Param("userId") int userId, @Param("activityId")int activityId);
}
