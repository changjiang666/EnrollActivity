package com.hust.mapper;

import com.hust.bean.Country;

import java.util.List;

public interface CountryMapper {

    List<Country> selectAll();
}
