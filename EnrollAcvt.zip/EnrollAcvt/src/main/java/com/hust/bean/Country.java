package com.hust.bean;

import org.springframework.stereotype.Component;

@Component("country")
public class Country {

    private Integer c_id;
    private String c_countryname;
    private String c_capital;

    public Country() {
    }

    @Override
    public String toString() {
        return "Country{" +
                "c_id=" + c_id +
                ", c_countryname='" + c_countryname + '\'' +
                ", c_capital='" + c_capital + '\'' +
                '}';
    }

    public Integer getC_id() {
        return c_id;
    }

    public void setC_id(Integer c_id) {
        this.c_id = c_id;
    }

    public String getC_countryname() {
        return c_countryname;
    }

    public void setC_countryname(String c_countryname) {
        this.c_countryname = c_countryname;
    }

    public String getC_capital() {
        return c_capital;
    }

    public void setC_capital(String c_capital) {
        this.c_capital = c_capital;
    }
}
