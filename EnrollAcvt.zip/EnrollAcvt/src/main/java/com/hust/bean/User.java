package com.hust.bean;
import org.springframework.stereotype.Component;

/*DROP TABLE IF EXISTS `tbl_user`;
        CREATE TABLE `tbl_user` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `openid` varchar(255) NOT NULL,
        `name` varchar(255) NOT NULL,
        `gender` varchar(0) NOT NULL,
        `age` int(11) NOT NULL,
        `phone` varchar(20) NOT NULL,
        `school` varchar(255) NOT NULL,
        PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;*/
@Component("user")
public class User {

    private int id;
    private String openid;
    private String name;
    private String avatarUrl;
    private String gender;
    private int age;
    private String phone;
    private String school;

    public User() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", openid='" + openid + '\'' +
                ", name='" + name + '\'' +
                ", avatarUrl='" + avatarUrl + '\'' +
                ", gender='" + gender + '\'' +
                ", age=" + age +
                ", phone='" + phone + '\'' +
                ", school='" + school + '\'' +
                '}';
    }
}
