package com.hust.bean;


import org.springframework.stereotype.Component;

/*DROP TABLE IF EXISTS `tbl_userLaunchActivity`;
        CREATE TABLE `tbl_userLaunchActivity` (
        `id` int(11) NOT NULL,
        `userId` int(11) NOT NULL,
        `launchActivityId` int(11) NOT NULL,
        PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;*/
@Component("userLaunchActivity")
public class UserLaunchActivity {

    private int id;
    private int userId;
    private int launchActivityId;

    public UserLaunchActivity() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getLaunchActivityId() {
        return launchActivityId;
    }

    public void setLaunchActivityId(int launchActivityId) {
        this.launchActivityId = launchActivityId;
    }

    @Override
    public String toString() {
        return "UserLaunchActivity{" +
                "id=" + id +
                ", userId=" + userId +
                ", launchActivityId=" + launchActivityId +
                '}';
    }
}
