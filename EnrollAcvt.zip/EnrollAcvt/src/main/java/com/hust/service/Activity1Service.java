package com.hust.service;

import com.hust.bean.*;
import com.hust.mapper.*;
import com.hust.utilis.GetApplicationContext;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component("activity1Service")
public class Activity1Service {

    private static ApplicationContext ac;
    static  {
        ac = GetApplicationContext.getInstance();
    }

    public Map<String, Object> selectEnrollActivity(int id) {
        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        List<Activity1> list = mapper.selectEnrollActivity(id);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("activityList", list);
        return map;
    }

    public void insertActivity(Activity1 activity1) {
        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        mapper.insertActivity(activity1);
    }

    public Map<String, Object> selectAllById(int userId, int activityId) {

        Map<String, Object> map = new HashMap<String, Object>();
        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        Activity1 activity1 = mapper.selectActivityById(activityId);
        map.put("Activity1", activity1);

        UserEnrollActivityMapper userEnrollActivityMapper = ac.getBean(UserEnrollActivityMapper.class);
        String comment = userEnrollActivityMapper.selectActivityCommentById(userId, activityId);
        map.put("Comment", comment);


        UserEnrollActivity userEnrollActivity = userEnrollActivityMapper.selectByUserIdAndActivityId(userId, activityId);
        Boolean isEnroll = true;
        if(userEnrollActivity == null)
            isEnroll = false;
        map.put("UserEnrollActivity", isEnroll);
        List<Integer> userIdList = userEnrollActivityMapper.selectUserIdByActivityId(activityId);


        UserConcernActivityMapper userConcernActivityMapper = ac.getBean(UserConcernActivityMapper.class);
        int cnt = userConcernActivityMapper.countAll(activityId);
        map.put("ConcernUserNum", cnt);

        Boolean isConcern = true;
        UserConcernActivity userConcernActivity = userConcernActivityMapper.selectByUserIdAndActivityID(userId, activityId);
        if(userConcernActivity == null)
            isConcern = false;
        map.put("UserConcernActivity", isConcern);


        UserGovernActivityMapper userGovernActivityMapper = ac.getBean(UserGovernActivityMapper.class);
        Boolean isGovern = true;
        UserGovernActivity userGovernActivity = userGovernActivityMapper.selectByUserIdAndActivityId(userId, activityId);
        if(userGovernActivity == null)
            isGovern = false;
        map.put("UserGovernActivity", isGovern);

        UserLaunchActivityMapper userLaunchActivityMapper = ac.getBean(UserLaunchActivityMapper.class);
        Boolean isLaunch = true;
        UserLaunchActivity userLaunchActivity = userLaunchActivityMapper.selectByUserIdAndActivityId(userId, activityId);
        if(userLaunchActivity == null)
            isLaunch = false;



        if(isGovern || isLaunch)
            map.put("userIdList", userIdList);
        else
            map.put("userIdList", null);

        return map;
    }
}
