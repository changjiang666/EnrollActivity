import com.hust.bean.Activity1;
import com.hust.mapper.Activity1Mapper;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class activity1Test {

    @Test
    public void testEnrollActivity() {
        ApplicationContext ac = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        List<Activity1> activity1List = mapper.selectEnrollActivity(1);
        for(Activity1 activity1 : activity1List) {
            System.out.println(activity1.toString());
        }
    }
}
