package com.hust.controller;

import com.alibaba.fastjson.JSONArray;
import com.hust.bean.Organization;
import com.hust.service.*;
import com.hust.utilis.SensitivewordFilter;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

@Controller
public class OrganizationController {

    private WebApplicationContext wac;

    private int check(Organization organization) {
        SensitivewordFilter filter = new SensitivewordFilter();
        Set<String> set1 = filter.getSensitiveWord(organization.getIntroduction(), 1);
        Set<String> set2 = filter.getSensitiveWord(organization.getName(), 1);
        if(set1.size() != 0 || set2.size() != 0)
            return 0;
        return 1;
    }


    // 根据orgId选择用户
    @RequestMapping("/selectOrgById")
    @ResponseBody
    public Organization selectOrgById(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        OrganizationService organizationService = wac.getBean(OrganizationService.class);

        int orgId = Integer.valueOf(req.getParameter("orgId"));
        return organizationService.selectOrgById(orgId);
    }


    // 根据orgId和userId判断用户是不是组织的管理者
    @RequestMapping("/isCreator")
    @ResponseBody
    public int isCreator(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserCreateOrgService userCreateOrgService = wac.getBean(UserCreateOrgService.class);

        int orgId = Integer.valueOf(req.getParameter("orgId"));
        int userId = Integer.valueOf(req.getParameter("userId"));
        List<Integer> list = userCreateOrgService.selectUserCreateOrgByUserId(userId);

        if(list.contains(orgId)) {
            return 1;
        }else {
            return 0;
        }
    }


    // 更新组织
    @RequestMapping("/updateOrg")
    @ResponseBody
    public int updateOrg(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        OrganizationService organizationService = wac.getBean(OrganizationService.class);

        int id = Integer.valueOf(req.getParameter("id"));
        String image = req.getParameter("image");
        String introduction = req.getParameter("introduction");
        String name = req.getParameter("name");
        String address = req.getParameter("address");
        String phone = req.getParameter("phone");


        Organization organization = new Organization();
        organization.setId(id);
        organization.setAddress(address);
        organization.setImage(image);
        organization.setIntroduction(introduction);
        organization.setName(name);
        organization.setPhone(phone);
        if(check(organization) == 1) {
            organizationService.updateOrg(organization);
            return 1;
        }
        else {
            System.out.println("输入非法内容!!!");
            return 0;
        }
    }


    // 向组织中插入一条记录
    @RequestMapping("/insertOrg")
    @ResponseBody
    public int insertOrg(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        OrganizationService organizationService = wac.getBean(OrganizationService.class);
        UserCreateOrgService userCreateOrgService = wac.getBean(UserCreateOrgService.class);

        String image = req.getParameter("image");
        String introduction = req.getParameter("introduction");
        String name = req.getParameter("name");
        String address = req.getParameter("address");
        String phone = req.getParameter("phone");
        int creatorId = Integer.valueOf(req.getParameter("creatorId"));


        Organization organization = new Organization();
        organization.setAddress(address);
        organization.setImage(image);
        organization.setIntroduction(introduction);
        organization.setName(name);
        organization.setPhone(phone);

        if(check(organization) == 1) {
            int orgId = organizationService.insertOrg(organization);
            userCreateOrgService.insertUserCreateOrg(creatorId, orgId);
            return 1;
        }

        else {
            System.out.println("输入非法内容!!!");
            return 0;
        }

    }



    // 更新组织的管理者
    @RequestMapping("/updateCreator")
    @ResponseBody
    public void updateCreator(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserCreateOrgService userCreateOrgService = wac.getBean(UserCreateOrgService.class);

        int orgId = Integer.valueOf(req.getParameter("orgId"));
        int creatorId = Integer.valueOf(req.getParameter("userId"));
        userCreateOrgService.updateCreator(creatorId, orgId);
    }

    // 根据组织的创建者userId选择组织
    @RequestMapping("/selectOrgByCreatorId")
    @ResponseBody
    public List<Organization> selectOrgByCreatorId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserCreateOrgService userCreateOrgService = wac.getBean(UserCreateOrgService.class);
        OrganizationService organizationService = wac.getBean(OrganizationService.class);
        int userId = Integer.valueOf(req.getParameter("userId"));
        List<Organization> list = new ArrayList<Organization>();
        List<Integer> orgIdList = userCreateOrgService.selectUserCreateOrgByUserId(userId);
        list = organizationService.selectOrgByIdList(orgIdList);
        return list;
    }


    // 根据orgId删除组织
    @RequestMapping("/deleteOrgById")
    @ResponseBody
    public void deleteOrgById(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        OrganizationService organizationService = wac.getBean(OrganizationService.class);

        int orgId = Integer.valueOf(req.getParameter("orgId"));
        organizationService.deleteOrgById(orgId);

        UserEnrollOrgService userEnrollOrgService = wac.getBean(UserEnrollOrgService.class);
        userEnrollOrgService.deleteUserEnrollOrgByOrgId(orgId);

        UserGovernOrgService userGovernOrgService = wac.getBean(UserGovernOrgService.class);
        userGovernOrgService.deleteUserEnrollOrgByOrgId(orgId);

        UserCreateOrgService userCreateOrgService =wac.getBean(UserCreateOrgService.class);
        userCreateOrgService.deleteUserCreateOrgByOrgId(orgId);

    }

    // 无条件选择所有的组织
    @RequestMapping("/selectAllOrg")
    @ResponseBody
    public List<Organization> selectAllOrg(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        OrganizationService organizationService = wac.getBean(OrganizationService.class);

        return organizationService.selectAllOrg();
    }


    // 根据组织的orgIdList删除组织
    @RequestMapping("/deleteOrgByIdList")
    @ResponseBody
    public List<Organization> deleteOrgByIdList(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        OrganizationService organizationService = wac.getBean(OrganizationService.class);
        UserEnrollOrgService userEnrollOrgService = wac.getBean(UserEnrollOrgService.class);
        UserGovernOrgService userGovernOrgService = wac.getBean(UserGovernOrgService.class);
        UserCreateOrgService userCreateOrgService =wac.getBean(UserCreateOrgService.class);

        String orgIdList = req.getParameter("orgIdList");
        List<Integer> idList;
        idList = JSONArray.parseArray(orgIdList,Integer.class);//这里的t是Class<T>*/

        for(Integer orgId : idList) {
            organizationService.deleteOrgById(orgId);
            userEnrollOrgService.deleteUserEnrollOrgByOrgId(orgId);
            userGovernOrgService.deleteUserEnrollOrgByOrgId(orgId);
            userCreateOrgService.deleteUserCreateOrgByOrgId(orgId);
        }
        List<Organization> list = organizationService.selectAllOrg();
        return list;
    }



    // 根据用户userId选择用户参与，管理，创建的组织
    @RequestMapping("/selectAllOrgByUserId")
    @ResponseBody
    public Map<String, Object> selectAllOrgByUserId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        int userId = Integer.valueOf(req.getParameter("userId"));
        OrganizationService organizationService = wac.getBean(OrganizationService.class);
        UserCreateOrgService userCreateOrgService = wac.getBean(UserCreateOrgService.class);
        UserGovernOrgService userGovernOrgService = wac.getBean(UserGovernOrgService.class);
        UserEnrollOrgService userEnrollOrgService = wac.getBean(UserEnrollOrgService.class);

        Map<String, Object> map = new HashMap<String, Object>();
        List<Integer> orgList = userCreateOrgService.selectUserCreateOrgByUserId(userId);
        if(orgList.size() != 0) {
            List<Organization> createOrg = organizationService.selectOrgByIdList(orgList);
            map.put("createOrg", createOrg);
        }


        orgList = userEnrollOrgService.selectOrgIdByUserId(userId);
        if(orgList.size() != 0) {
            List<Organization> enrollOrg = organizationService.selectOrgByIdList(orgList);
            map.put("enrollOrg", enrollOrg);
        }

        orgList = userGovernOrgService.selectUserGovernOrgByUserId(userId);
        if(orgList.size() != 0) {
            List<Organization> governOrg = organizationService.selectOrgByIdList(orgList);
            map.put("governOrg", governOrg);
        }

        return map;
    }

}
