package com.hust.controller;

import com.alibaba.fastjson.JSONArray;
import com.hust.bean.Activity1;
import com.hust.bean.Activity2;
import com.hust.bean.Organization;
import com.hust.service.*;
import com.hust.utilis.SensitivewordFilter;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

@Controller
public class Activity1Controller {

    private WebApplicationContext wac;

    private int check(Activity1 activity1) {

        SensitivewordFilter filter = new SensitivewordFilter();
        Set<String> set1 = filter.getSensitiveWord(activity1.getContent(), 1);
        Set<String> set2 = filter.getSensitiveWord(activity1.getTitle(), 1);
        if(set1.size() != 0 || set2.size() != 0)
            return 0;
        return 1;
    }


    // 根据activityId选择一条活动记录
    // 操作tbl_activity1表
    @RequestMapping("/selectEnrollActivity")
    @ResponseBody
    public Map<String, Object> selectEnrollActivity(HttpServletRequest req, HttpServletResponse response) {
        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        Activity1Service activity1Service = wac.getBean(Activity1Service.class);
        int activityId = Integer.valueOf(req.getParameter("activityId"));
        Map<String, Object> map = activity1Service.selectEnrollActivity(activityId);
        System.out.println(map.toString());
        return map;
    }


    // 根据userId和activityId返回活动和用户的各种信息
    @RequestMapping("/selectAllById")
    @ResponseBody
    public Map<String, Object> selectAllById(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        Activity1Service activity1Service = wac.getBean(Activity1Service.class);
        int userId = Integer.valueOf(req.getParameter("userId"));
        int activityId  = Integer.valueOf(req.getParameter("activityId"));
        Map<String, Object> map =  activity1Service.selectAllById(userId, activityId);
        System.out.println(map);
        return map;
    }


    // 向活动表中插入一条记录
    // 操作tbl_activity1和tbl_activity2表
    @RequestMapping("/insertUserCreateActivity")
    @ResponseBody
    public int insertUserCreateActivity(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        Activity1Service activity1Service = wac.getBean(Activity1Service.class);


        int orgId = Integer.valueOf(req.getParameter("orgId"));
        String imageHead = req.getParameter("imageHead");
        String type = req.getParameter("type");
        String title = req.getParameter("title");
        String content = req.getParameter("content");
        String avtivityStartTime = req.getParameter("avtivityStartTime");
        String activityEndTime = req.getParameter("activityEndTime");
        String enrollEndTime = req.getParameter("enrollEndTime");
        String address = req.getParameter("address");
        String longitude = req.getParameter("longitude");
        String latitude = req.getParameter("latitude");
        String activityKey = req.getParameter("activityKey");
        String phone = req.getParameter("phone");
        int isPublic = Integer.valueOf(req.getParameter("isPublic"));

        Activity1 activity1 = new Activity1();
        activity1.setOrgId(orgId);
        activity1.setImageHead(imageHead);
        activity1.setType(type);
        activity1.setTitle(title);
        activity1.setContent(content);
        activity1.setActivityEndTime(activityEndTime);
        activity1.setAvtivityStartTime(avtivityStartTime);
        activity1.setEnrollEndTime(enrollEndTime);
        activity1.setAddress(address);
        activity1.setLatitude(latitude);
        activity1.setLongitude(longitude);
        activity1.setActivityKey(activityKey);
        activity1.setCurrentPersonNum(0);
        activity1.setIsPublic(isPublic);
        activity1.setPhone(phone);


        int isName = Integer.valueOf(req.getParameter("isName"));
        int isGender = Integer.valueOf(req.getParameter("isGender"));
        int isAge = Integer.valueOf(req.getParameter("isAge"));
        int isPhone = Integer.valueOf(req.getParameter("isPhone"));
        int isCorporation = Integer.valueOf(req.getParameter("isCorporation"));
        int personLimit = Integer.valueOf(req.getParameter("personLimit"));
        Activity2 activity2 = new Activity2();
        activity2.setIsGender(isGender);
        activity2.setIsName(isName);
        activity2.setIsCorporation(isCorporation);
        activity2.setPersonLimit(personLimit);
        activity2.setIsAge(isAge);
        activity2.setIsPhone(isPhone);


        int userId = Integer.valueOf(req.getParameter("userId"));
        if(check(activity1) == 1) {
            activity1Service.insertActivity1(activity1);
            activity1Service.insertUserCreateActivity(activity1, activity2, userId);
            return 1;
        }
        else {
            System.out.println("输入非法内容！！！");
            return 0;

        }
    }



    // 更新活动记录
    // 修改tbl_activity1和tbl_activity2
    @RequestMapping("/updateActivity")
    @ResponseBody
    public void updateActivity(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        Activity1Service activity1Service = wac.getBean(Activity1Service.class);

        int orgId = Integer.valueOf(req.getParameter("orgId"));
        String imageHead = req.getParameter("imageHead");
        String type = req.getParameter("type");
        String title = req.getParameter("title");
        String content = req.getParameter("content");
        String avtivityStartTime = req.getParameter("avtivityStartTime");
        String activityEndTime = req.getParameter("activityEndTime");
        String enrollEndTime = req.getParameter("enrollEndTime");
        String address = req.getParameter("address");
        String longitude = req.getParameter("longitude");
        String latitude = req.getParameter("latitude");
        String activityKey = req.getParameter("activityKey");
        String imageList = req.getParameter("imageList");
        String phone = req.getParameter("phone");
        int isPublic = Integer.valueOf(req.getParameter("isPublic"));

        Activity1 activity1 = new Activity1();
        activity1.setIsPublic(isPublic);
        activity1.setPhone(phone);
        activity1.setImageList(imageList);
        activity1.setOrgId(orgId);
        activity1.setImageHead(imageHead);
        activity1.setType(type);
        activity1.setTitle(title);
        activity1.setContent(content);
        activity1.setActivityEndTime(activityEndTime);
        activity1.setAvtivityStartTime(avtivityStartTime);
        activity1.setEnrollEndTime(enrollEndTime);
        activity1.setAddress(address);
        activity1.setLatitude(latitude);
        activity1.setLongitude(longitude);
        activity1.setActivityKey(activityKey);


        int isName = Integer.valueOf(req.getParameter("isName"));
        int isGende = Integer.valueOf(req.getParameter("isGende"));
        int isAge = Integer.valueOf(req.getParameter("isAge"));
        int isPhone = Integer.valueOf(req.getParameter("isPhone"));
        int isCorporation = Integer.valueOf(req.getParameter("isCorporation"));
        int personLimit = Integer.valueOf(req.getParameter("personLimit"));
        Activity2 activity2 = new Activity2();
        activity2.setIsGender(isGende);
        activity2.setIsName(isName);
        activity2.setIsCorporation(isCorporation);
        activity2.setPersonLimit(personLimit);
        activity2.setIsAge(isAge);
        activity2.setIsPhone(isPhone);

        int userId = Integer.valueOf(req.getParameter("userId"));
        if(check(activity1) == 1)
            activity1Service.updateActivity(activity1, activity2, userId);
        else {
            System.out.println("输入非法内容！！！");
        }
    }


    // 根据activityIdList选择活动
    @RequestMapping("/selectActivityListByIdList")
    @ResponseBody
    public List<Activity1> selectActivityListByIdList(HttpServletRequest req, HttpServletResponse response
                                                      ,@RequestParam("activityIdList") List<Integer> activityIdList) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        Activity1Service activity1Service = wac.getBean(Activity1Service.class);
        return activity1Service.selectActivityListByIdList(activityIdList);
    }

    // 根据activityId删除活动
    @RequestMapping("/deleteActivity")
    @ResponseBody
    public void deleteActivity(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        int activityId = Integer.valueOf(req.getParameter("activityId"));

        Activity1Service activity1Service = wac.getBean(Activity1Service.class);
        activity1Service.deleteActivity1(activityId);
        activity1Service.deleteActivity2(activityId);

        UserConcernActivityService userConcernActivityService = wac.getBean(UserConcernActivityService.class);
        userConcernActivityService.deleteRecordByActivityId(activityId);

        UserGovernActivityService userGovernActivityService = wac.getBean(UserGovernActivityService.class);
        userGovernActivityService.deleteRecordByActivityId(activityId);

        UserEnrollActivityService userEnrollActivityService = wac.getBean(UserEnrollActivityService.class);
        userEnrollActivityService.deleteRecordByActivityId(activityId);

        UserLaunchActivityService userLaunchActivityService = wac.getBean(UserLaunchActivityService.class);
        userLaunchActivityService.deleteRecordByActivityId(activityId);

    }


    // 返回活动表中的所有活动，用于在地图中显示
    @RequestMapping("/getTypeById")
    @ResponseBody
    public List<Activity1> getTypeById(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        Activity1Service activity1Service = wac.getBean(Activity1Service.class);
        List<Activity1> activity1List =  activity1Service.getTypeById();
        System.out.println(activity1List);
        return activity1List;
    }



    // 根据activityId选择tbl_activity2中的一条记录
    @RequestMapping("/selectActivity2ById")
    @ResponseBody
    public Activity2 selectActivity2ById(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        Activity1Service activity1Service = wac.getBean(Activity1Service.class);
        int activityId = Integer.valueOf(req.getParameter("activityId"));
        Activity2 activity2 = activity1Service.selectActivity2ById(activityId);
        return activity2;
    }


    // 接口重复，与上上一个接口的作用相同
    @RequestMapping("/selectAllActivity")
    @ResponseBody
    public List<Activity1> selectAllActivity(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        Activity1Service activity1Service = wac.getBean(Activity1Service.class);

        List<Activity1> list = activity1Service.selectAllActivity();
        return list;
    }


    // 根据activityIdList删除活动表中的活动
    @RequestMapping("/deleteActivityByIdList")
    @ResponseBody
    public List<Activity1> deleteActivityByIdList(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        String activityIdList = req.getParameter("activityIdList");
        List<Integer> idList;
        idList = JSONArray.parseArray(activityIdList,Integer.class);//这里的t是Class<T>*/
        Activity1Service activity1Service = wac.getBean(Activity1Service.class);
        UserConcernActivityService userConcernActivityService = wac.getBean(UserConcernActivityService.class);
        UserGovernActivityService userGovernActivityService = wac.getBean(UserGovernActivityService.class);
        UserEnrollActivityService userEnrollActivityService = wac.getBean(UserEnrollActivityService.class);
        UserLaunchActivityService userLaunchActivityService = wac.getBean(UserLaunchActivityService.class);

        System.out.println(idList);

        for(Integer activityId : idList) {
            activity1Service.deleteActivity1(activityId);
            activity1Service.deleteActivity2(activityId);
            userConcernActivityService.deleteRecordByActivityId(activityId);
            userGovernActivityService.deleteRecordByActivityId(activityId);
            userEnrollActivityService.deleteRecordByActivityId(activityId);
            userLaunchActivityService.deleteRecordByActivityId(activityId);
        }

        List<Activity1> list = activity1Service.selectAllActivity();
        return list;
    }


    // 根据orgId选择组织创建的活动
    @RequestMapping("/selectActivityByOrgId")
    @ResponseBody
    public List<Activity1> selectActivityByOrgId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        Activity1Service activity1Service = wac.getBean(Activity1Service.class);

        int orgId = Integer.valueOf(req.getParameter("orgId"));
        List<Activity1> list = activity1Service.selectActivityByOrgId(orgId);
        return list;
    }


    // 根据userId选择用户参与，关注，管理，创建的活动
    @RequestMapping("/selectActivityByUserId")
    @ResponseBody
    public Map<String, Object> selectActivityByUserId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        int userId = Integer.valueOf(req.getParameter("userId"));
        Activity1Service activity1Service = wac.getBean(Activity1Service.class);
        UserConcernActivityService userConcernActivityService = wac.getBean(UserConcernActivityService.class);
        UserGovernActivityService userGovernActivityService = wac.getBean(UserGovernActivityService.class);
        UserEnrollActivityService userEnrollActivityService = wac.getBean(UserEnrollActivityService.class);
        UserLaunchActivityService userLaunchActivityService = wac.getBean(UserLaunchActivityService.class);

        Map<String, Object> map = new HashMap<String, Object>();
        List<Integer> activityIdList = userEnrollActivityService.selectUserEnrollActivityByUserId(userId);

        if(activityIdList.size() != 0) {
            List<Activity1> enrollList = activity1Service.selectActivityListByIdList(activityIdList);
            map.put("enrollList", enrollList);

            activityIdList = userGovernActivityService.selectUserGovernActivityByUserId(userId);
            List<Activity1> governList = activity1Service.selectActivityListByIdList(activityIdList);
            map.put("governList", governList);

            activityIdList = userConcernActivityService.selectUserConcernActivity(userId);
            List<Activity1> concernList = activity1Service.selectActivityListByIdList(activityIdList);
            map.put("concernList", concernList);

            activityIdList = userGovernActivityService.selectUserGovernActivityByUserId(userId);
            List<Activity1> launchList = activity1Service.selectActivityListByIdList(activityIdList);
            map.put("launchList", launchList);
        }

        return map;
    }

    // 根据activityId选择与活动相关的组织
    @RequestMapping("/selectAllOrgByActivityId")
    @ResponseBody
    public List<Organization> selectAllOrgByActivityId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        Activity1Service activity1Service = wac.getBean(Activity1Service.class);

        int activityId = Integer.valueOf(req.getParameter("activityId"));
        Organization activityOrg = activity1Service.selectAllOrgByActivityId(activityId);

        List<Organization> list = new ArrayList<Organization>();
        list.add(activityOrg);
        return list;
    }

}
