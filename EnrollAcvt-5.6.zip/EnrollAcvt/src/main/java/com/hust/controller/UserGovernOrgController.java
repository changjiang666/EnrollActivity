package com.hust.controller;


import com.hust.bean.Organization;
import com.hust.bean.User;
import com.hust.service.OrganizationService;
import com.hust.service.UserGovernOrgService;
import com.hust.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
public class UserGovernOrgController {

    private WebApplicationContext wac;


    // 根据userId选择用户关注的组织
    @RequestMapping("/selectUserGovernOrgByUserId")
    @ResponseBody
    public List<Organization> selectUserGovernOrgByUserId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserGovernOrgService userGovernOrgService = wac.getBean(UserGovernOrgService.class);
        int userId = Integer.valueOf(req.getParameter("userId"));
        List<Integer> orgIdList = userGovernOrgService.selectUserGovernOrgByUserId(userId);

        OrganizationService organizationService = wac.getBean(OrganizationService.class);
        List<Organization> list = organizationService.selectOrgByIdList(orgIdList);

        return list.size() == 0 ? null : list;
    }


    // 根据orgId选择该组织的管理者
    @RequestMapping("/selectUserGovernOrgByOrgId")
    @ResponseBody
    public List<User> selectUserGovernOrgByOrgId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserGovernOrgService userGovernOrgService = wac.getBean(UserGovernOrgService.class);
        int orgId = Integer.valueOf(req.getParameter("orgId"));
        List<Integer> userIdList = userGovernOrgService.selectUserGovernOrgByOrgId(orgId);

        UserService userService = wac.getBean(UserService.class);
        return userService.selectUserByIdList(userIdList);

    }


    // 插入一条记录
    @RequestMapping("/insertUserGovernOrg")
    @ResponseBody
    public void insertUserGovernOrg(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserGovernOrgService userGovernOrgService = wac.getBean(UserGovernOrgService.class);
        int orgId = Integer.valueOf(req.getParameter("orgId"));
        int userId = Integer.valueOf(req.getParameter("userId"));
        userGovernOrgService.insertUserGovernOrg(userId, orgId);
    }


    // 删除一条记录
    @RequestMapping("/deleteUserGovernOrg")
    @ResponseBody
    public void deleteUserGovernOrg(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserGovernOrgService userGovernOrgService = wac.getBean(UserGovernOrgService.class);
        int orgId = Integer.valueOf(req.getParameter("orgId"));
        int userId = Integer.valueOf(req.getParameter("userId"));
        userGovernOrgService.deleteUserGovernOrg(userId, orgId);
    }

}
