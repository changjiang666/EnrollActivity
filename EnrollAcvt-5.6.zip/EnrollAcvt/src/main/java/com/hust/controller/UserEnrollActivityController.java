package com.hust.controller;

import com.hust.bean.Activity1;
import com.hust.service.Activity1Service;
import com.hust.service.UserEnrollActivityService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
public class UserEnrollActivityController {

    private WebApplicationContext wac;


    // 插入用户参与的活动
    // 注意在tbl_activity1中要做相应的修改
    @RequestMapping("InsertUserEnrollActivity")
    @ResponseBody
    public void InsertUserEnrollActivity(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserEnrollActivityService userEnrollActivityService = wac.getBean(UserEnrollActivityService.class);
        int userId = Integer.valueOf(req.getParameter("userId"));
        int activityId = Integer.valueOf(req.getParameter("activityId"));
        userEnrollActivityService.InsertUserEnrollActivity(userId, activityId);

        Activity1Service activity1Service= wac.getBean(Activity1Service.class);
        activity1Service.updateCurrentPersonNum();
    }


    // 删除用户参与的活动
    // 注意在tbl_activity1中要做相应的修改
    @RequestMapping("deleteUserEnrollActivity")
    @ResponseBody
    public void deleteUserEnrollActivity(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserEnrollActivityService userEnrollActivityService = wac.getBean(UserEnrollActivityService.class);
        int userId = Integer.valueOf(req.getParameter("userId"));
        int activityId = Integer.valueOf(req.getParameter("activityId"));
        userEnrollActivityService.deleteUserEnrollActivity(userId, activityId);
        Activity1Service activity1Service= wac.getBean(Activity1Service.class);
        activity1Service.updateCurrentPersonNum1();
    }



    // 根据userId选择用户参与的活动
    @RequestMapping("selectUserEnrollActivityByUserId")
    @ResponseBody
    public List<Activity1> selectUserEnrollActivityByUserId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserEnrollActivityService userEnrollActivityService = wac.getBean(UserEnrollActivityService.class);
        int userId = Integer.valueOf(req.getParameter("userId"));
        List<Integer> activityIdList = userEnrollActivityService.selectUserEnrollActivityByUserId(userId);

        Activity1Service activity1Service = wac.getBean(Activity1Service.class);
        List<Activity1> activity1List = activity1Service.selectActivityListByIdList(activityIdList);
        return activity1List;
    }

    // 根据userId和activityId删除评论
    @RequestMapping("deleteCommentById")
    @ResponseBody
    public void deleteCommentById(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserEnrollActivityService userEnrollActivityService = wac.getBean(UserEnrollActivityService.class);
        int userId = Integer.valueOf(req.getParameter("userId"));
        int activityId = Integer.valueOf(req.getParameter("activityId"));

        userEnrollActivityService.deleteCommentById(userId, activityId);
    }
}
