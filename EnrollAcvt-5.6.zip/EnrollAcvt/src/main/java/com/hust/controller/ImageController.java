package com.hust.controller;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class ImageController {

    private WebApplicationContext wac;

    @RequestMapping("/upLoadImage")
    @ResponseBody
    public Map<String, Object> upLoadImage(HttpServletRequest req, HttpServletResponse response) throws Exception {
        wac = WebApplicationContextUtils.getWebApplicationContext(req.getServletContext());
        System.out.println("进入方法");
        Map<String,Object> map = new HashMap<String,Object>();

        // 验证请求是否满足要求（post 请求 / enctype 是否以multipart打头
        boolean isMultipart = ServletFileUpload.isMultipartContent(req);
        // 如果不满足要求就立即结束对该请求的处理
        System.out.println("ServletFileUpload.isMultipartContent(req);");
        if (!isMultipart) {
            System.out.println("!isMultipart");
            return map;
        }


        // FileItem 是表单中的每一个元素的封装
        // 创建一个 FileItem 的工厂类
        FileItemFactory factory = new DiskFileItemFactory();
        // 创建一个文件上传处理器（装饰设计模式）
        ServletFileUpload upload = new ServletFileUpload(factory);
        // 解析请求
        List<FileItem> items = upload.parseRequest(req);
        for (FileItem fileItem :
                items) {
            // 判断空间是否是普通控件
            System.out.println("判断空间是否是普通控件");
            if (fileItem.isFormField()) {
                System.out.println("是普通控件");
            } else {
                System.out.println("准备上传");
                // 上传控件
                // 将上传的文件保存到服务器
                String s1 = ""+(1+Math.random()*10);
                map.put("address", s1+".jpg");

                /*String t=Thread.currentThread().getContextClassLoader().getResource("").getPath();
                System.out.println(t);*/

                String s11 = req.getSession().getServletContext().getRealPath("/");
                s11 += "WEB-INF\\image";
                System.out.println(s11);
                fileItem.write(new File(s11, s1+".jpg"));
            }
        }
        return  map;

    }
}
