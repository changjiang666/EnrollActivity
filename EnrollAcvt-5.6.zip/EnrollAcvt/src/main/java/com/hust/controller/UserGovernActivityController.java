package com.hust.controller;

import com.hust.bean.Activity1;
import com.hust.bean.User;
import com.hust.service.Activity1Service;
import com.hust.service.UserGovernActivityService;
import com.hust.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
public class UserGovernActivityController {

    private WebApplicationContext wac;


    // 插入一条记录
    @RequestMapping("/insertUserGovernActivityById")
    @ResponseBody
    public void insertUserGovernActivityById(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserGovernActivityService userGovernActivityService = wac.getBean(UserGovernActivityService.class);

        int userId = Integer.valueOf(req.getParameter("userId"));
        int activityId = Integer.valueOf(req.getParameter("activityId"));
        userGovernActivityService.insertUserGovernActivityById(userId, activityId);
    }


    // 根据userId和activityId删除一条记录
    @RequestMapping("/deleteUserGovernActivityById")
    @ResponseBody
    public void deleteUserGovernActivityById(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserGovernActivityService userGovernActivityService = wac.getBean(UserGovernActivityService.class);

        int userId = Integer.valueOf(req.getParameter("userId"));
        int activityId = Integer.valueOf(req.getParameter("activityId"));

        userGovernActivityService.deleteUserGovernActivityById(userId, activityId);
    }


    // 根据userId选择用户管理的活动
    @RequestMapping("selectUserGovernActivityByUserId")
    @ResponseBody
    public List<Activity1> selectUserGovernActivityByUserId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserGovernActivityService userGovernActivityService = wac.getBean(UserGovernActivityService.class);
        int userId = Integer.valueOf(req.getParameter("userId"));
        List<Integer> activityIdList = userGovernActivityService.selectUserGovernActivityByUserId(userId);
        Activity1Service activity1Service =wac.getBean(Activity1Service.class);
        return activity1Service.selectActivityListByIdList(activityIdList);
    }


    // 根据activityId选择该活动的管理者
    @RequestMapping("selectUserGovernActivityByActivityId")
    @ResponseBody
    public List<User> selectUserGovernActivityByActivityId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserGovernActivityService userGovernActivityService = wac.getBean(UserGovernActivityService.class);
        int activityId = Integer.valueOf(req.getParameter("activityId"));
        List<Integer> userIdList = userGovernActivityService.selectUserGovernActivityByActivityId(activityId);

        UserService userService = wac.getBean(UserService.class);
        List<User> userList =  userService.selectUserByIdList(userIdList);
        for(User u:userList) {
            u.setOpenid(null);
        }
        return userList;
    }
}
