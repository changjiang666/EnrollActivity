package com.hust.controller;

import com.hust.bean.Organization;
import com.hust.service.OrganizationService;
import com.hust.service.UserCreateOrgService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;


@Controller
public class UserCreateOrgController {

    private WebApplicationContext wac;

    // 根据orgId删除用户创建的组织
    @RequestMapping("/deleteUserCreateOrgByOrgId")
    @ResponseBody
    public void deleteUserCreateOrgByOrgId(HttpServletRequest req, HttpServletResponse response) {
        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserCreateOrgService userCreateOrgService = wac.getBean(UserCreateOrgService.class);
        int orgId = Integer.valueOf(req.getParameter("orgId"));
        userCreateOrgService.deleteUserCreateOrgByOrgId(orgId);
    }



    // 根据userId选择用户创建的组织
    @RequestMapping("/selectUserCreateOrgByUserId")
    @ResponseBody
    public List<Organization> selectUserCreateOrgByUserId(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserCreateOrgService userCreateOrgService = wac.getBean(UserCreateOrgService.class);

        int userId = Integer.valueOf(req.getParameter("userId"));
        List<Integer> orgIdList = userCreateOrgService.selectUserCreateOrgByUserId(userId);

        OrganizationService organizationService = wac.getBean(OrganizationService.class);
        return organizationService.selectOrgByIdList(orgIdList);
    }

    // 判断用户是组织的管理员
    // 如果是，返回1；否则返回0
    @RequestMapping("/isOrgCreator")
    @ResponseBody
    public int isOrgCreator(HttpServletRequest req, HttpServletResponse response) {
        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserCreateOrgService userCreateOrgService = wac.getBean(UserCreateOrgService.class);
        int userId = Integer.valueOf(req.getParameter("userId"));
        int orgId = Integer.valueOf(req.getParameter("orgId"));
        List<Integer> orgIdList = userCreateOrgService.selectUserCreateOrgByUserId(userId);
        if(orgIdList.contains(orgId)) {
            return 1;
        }
        return 0;
    }
}
