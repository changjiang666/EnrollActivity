package com.hust.controller;

import com.hust.bean.Activity1;
import com.hust.service.Activity1Service;
import com.hust.service.UserConcernActivityService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;


@Controller
public class UserConcernActivityController {

    private WebApplicationContext wac;


    // 根据userId 和 activityId 更新用户关注的活动
    @RequestMapping("updateConcern")
    @ResponseBody
    public void updateConcern(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserConcernActivityService userConcernActivityService = wac.getBean(UserConcernActivityService.class);
        int userId = Integer.valueOf(req.getParameter("userId"));
        int activityId = Integer.valueOf(req.getParameter("activityId"));
        userConcernActivityService.updateConcern(userId, activityId);
    }


    // 根据用户userId选择用户关注的活动
    @RequestMapping("selectUserConcernActivity")
    @ResponseBody
    public List<Activity1> selectUserConcernActivity(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserConcernActivityService userConcernActivityService = wac.getBean(UserConcernActivityService.class);
        int userId = Integer.valueOf(req.getParameter("userId"));
        List<Integer> activityIdList = userConcernActivityService.selectUserConcernActivity(userId);

        Activity1Service activity1Service =wac.getBean(Activity1Service.class);
        return activity1Service.selectActivityListByIdList(activityIdList);
    }


}
