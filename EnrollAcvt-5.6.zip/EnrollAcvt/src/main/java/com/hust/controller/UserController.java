package com.hust.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.hust.bean.User;
import com.hust.service.*;
import com.hust.utilis.CommonUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Controller
public class UserController {

    private static final String APPID = "wx59a539d568342578";
    private static final String SECRET = "7e60798093488c30eb6010330f8f3903";
    private WebApplicationContext wac;


    // 根据code 插入一个用户
    // 返回插入后的用户id
    @RequestMapping(value="/insertUser")
    @ResponseBody
    public User insertUser(HttpServletRequest req, HttpServletResponse response) {
        Map<String, Object> map = new HashMap<String, Object>();
        String status = "1";
        String msg = "ok";
        String code = req.getParameter("code");
        /*String code = "021vEpk9136ZON11Mul91UlJk91vEpkb";*/
        String requestUrl = "https://api.weixin.qq.com/sns/jscode2session?appid=" + APPID + "&secret=" + SECRET + "&js_code=" + code + "&grant_type=authorization_code";
        try {
            if (code == null) {
                status = "0";//失败状态
                msg = "code为空";
            } else {
                JSONObject jsonObject = CommonUtil.httpsRequest(requestUrl, "POST", null);
                if (jsonObject != null) {
                    try {
                        map.put("openid", jsonObject.getString("openid"));
                        map.put("session_key", jsonObject.getString("session_key"));
                    } catch (JSONException e) {
                        // 获取token失败
                        status = "0";
                        msg = "code无效";
                    }
                } else {
                    status = "0";
                    msg = "code无效";
                }
            }
            map.put("status", status);
            map.put("msg", msg);
        } catch (Exception e) {
        }
        Object openid = map.get("openid");


        String name = req.getParameter("nickName");
        String avatarUrl = req.getParameter("avatarUrl");
        String gender = req.getParameter("gender");
        User user = new User();
        user.setName(name);
        user.setOpenid(openid.toString());
        user.setGender(gender);
        user.setAvatarUrl(avatarUrl);


        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserService userService = wac.getBean(UserService.class);
        return userService.insertUser(user);
    }



    // 更新用户
    @RequestMapping(value="/updateUser")
    @ResponseBody
    //int id, String phone, String school, int age, String gander
    public void updateUser(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserService userService = wac.getBean(UserService.class);

        User user = new User();

        int id = Integer.valueOf(req.getParameter("id"));
        String name = req.getParameter("name");
        String school = req.getParameter("school");
        int age = Integer.valueOf(req.getParameter("age"));
        String phone = req.getParameter("phone");
        String gender = req.getParameter("gender");


        user.setSchool(school);
        user.setGender(gender);
        user.setAge(age);
        user.setId(id);
        user.setPhone(phone);
        user.setName(name);
        userService.updateUser(user);

    }


    // 根据userIdList选择一批用户
    @RequestMapping(value="/selectUserById")
    @ResponseBody
    //List<int> id, bool hasGender, bool hasAvatraUrl, bool hasAge, bool hasPhone, bool hasSchool
    public Map<String, Object> selectUserById(HttpServletRequest req, HttpServletResponse response
            ,@RequestParam("userIdList") List<Integer> idList) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserService userService = wac.getBean(UserService.class);

        Map<String, Object> ans = new HashMap<String, Object>();
        List<User> uList = new ArrayList<User>();

        for(Integer id :idList) {
            User user = userService.selectUserById(id);
            user.setOpenid(null);
            uList.add(user);
        }
        ans.put("uList",uList);

        System.out.println(ans);
        return ans;
    }

    // 无条件选择所有的用户
    @RequestMapping(value="/selectAllUser")
    @ResponseBody
    //List<int> id, bool hasGender, bool hasAvatraUrl, bool hasAge, bool hasPhone, bool hasSchool
    public Map<String, Object> selectAllUser(HttpServletRequest req, HttpServletResponse response) {

        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserService userService = wac.getBean(UserService.class);

        Map<String, Object> ans = new HashMap<String, Object>();
        List<User> uList = new ArrayList<User>();
        uList = userService.selectAllUser();

        ans.put("uList",uList);
        return ans;
    }


    // 删除选中的用户
    @RequestMapping(value="/deleteSelect")
    @ResponseBody
    //List<int> id, bool hasGender, bool hasAvatraUrl, bool hasAge, bool hasPhone, bool hasSchool
    public List<User> deleteSelect(HttpServletRequest req, HttpServletResponse response) {
        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserService userService = wac.getBean(UserService.class);

        String userIdList = req.getParameter("userIdList");
        List<Integer> idList;
        idList = JSONArray.parseArray(userIdList,Integer.class);//这里的t是Class<T>*/
        System.out.println(userIdList);
        List<User> userList = userService.deleteSelect(idList);
        return userList;
    }


    // 根据orgId选择组织的参与者，创建者和管理者
    @RequestMapping(value="/selectUserByOrgId")
    @ResponseBody
    public Map<String, Object> selectUserByOrgId(HttpServletRequest req, HttpServletResponse response) {
        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserService userService = wac.getBean(UserService.class);
        UserCreateOrgService userCreateOrgService = wac.getBean(UserCreateOrgService.class);
        UserEnrollOrgService userEnrollOrgService = wac.getBean(UserEnrollOrgService.class);
        UserGovernOrgService userGovernOrgService = wac.getBean(UserGovernOrgService.class);
        Map<String, Object> map = new HashMap<String, Object>();

        int orgId = Integer.valueOf(req.getParameter("orgId"));

        List<Integer> idList = userCreateOrgService.selectUserCreateOrgByOrgId(orgId);
        if(idList.size() != 0) {
            List<User> orgCreatorList = userService.selectUserByIdList(idList);
            map.put("orgCreatorList", orgCreatorList);
        }


        idList = userEnrollOrgService.selectUserEnrollOrgByOrgId(orgId);
        if(idList.size() != 0) {
            List<User> orgEnrollUserList = userService.selectUserByIdList(idList);
            map.put("orgEnrollUserList", orgEnrollUserList);
        }


        idList = userGovernOrgService.selectUserGovernOrgByOrgId(orgId);
        if(idList.size() != 0) {
            List<User> orgGovernorList = userService.selectUserByIdList(idList);
            map.put("orgGovernorList", orgGovernorList);
        }
        return map;
    }



    // 根据activityId选择活动的参与者，关注者，管理者和创建者
    @RequestMapping(value="/selectAllUserByActivityId")
    @ResponseBody
    public Map<String, Object> selectAllUserByActivityId(HttpServletRequest req, HttpServletResponse response) {
        wac = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
        UserService userService = wac.getBean(UserService.class);
        UserEnrollActivityService userEnrollActivityService = wac.getBean(UserEnrollActivityService.class);
        UserGovernActivityService userGovernActivityService = wac.getBean(UserGovernActivityService.class);
        UserConcernActivityService userConcernActivityService = wac.getBean(UserConcernActivityService.class);
        UserLaunchActivityService userLaunchActivityService = wac.getBean(UserLaunchActivityService.class);
        //int activityId = Integer.valueOf(req.getParameter("activityId"));
        int activityId = 1;
        Map<String, Object> map = new HashMap<String, Object>();

        List<Integer> idList = userEnrollActivityService.selectUserEnrollActivityByActivityId(activityId);
        if(idList.size() != 0) {
            List<User> activityEnrollorList = userService.selectUserByIdList(idList);
            map.put("activityEnrollorList", activityEnrollorList);
        }


        idList = userConcernActivityService.selectUserConcernActivityByActivityId(activityId);
        if(idList.size() != 0) {
            List<User> activityConcernorList = userService.selectUserByIdList(idList);
            map.put("activityConcernorList", activityConcernorList);
        }


        idList = userGovernActivityService.selectUserGovernActivityByActivityId(activityId);
        if(idList.size() != 0) {
            List<User> activityGovernorList = userService.selectUserByIdList(idList);
            map.put("activityGovernorList", activityGovernorList);
        }


        idList = userLaunchActivityService.selectUserLaunchActivityByActivityId(activityId);
        if(idList.size()!= 0) {
            List<User> activityLaunchorList = userService.selectUserByIdList(idList);
            map.put("activityLaunchorList", activityLaunchorList);
        }
        
        return map;
    }

}



