package com.hust.mapper;

import com.hust.bean.UserConcernActivity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserConcernActivityMapper {

    int countAll(int activityId);

    UserConcernActivity selectByUserIdAndActivityID(@Param("userId") int userId, @Param("activityId") int activityId);

    void insertUserConcernActivity(@Param("userId") int userId, @Param("activityId") int activityId);

    void delectUserConcernActivity(@Param("userId") int userId, @Param("activityId") int activityId);

    List<Integer> selectUserConcernActivity(int userId);

    void deleteRecordByActivityId(int activityId);

    List<Integer> selectUserConcernActivityByActivityId(int activityId);
}
