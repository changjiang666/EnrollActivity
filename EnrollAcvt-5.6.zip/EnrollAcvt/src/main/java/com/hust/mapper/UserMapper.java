package com.hust.mapper;

import com.hust.bean.User;

import java.util.List;

public interface UserMapper {

    void insertUser(User user);

    User selectUserByOpenId(User user);

    void updateUser(User user);

    User selectUserById(Integer id);

    List<User> selectUserByIdList(List<Integer> userIdList);

    List<User> selectAllUser();

    void deleteUserByIdList(List<Integer> userIdList);

}
