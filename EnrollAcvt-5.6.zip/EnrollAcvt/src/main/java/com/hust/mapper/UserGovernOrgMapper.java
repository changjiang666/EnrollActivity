package com.hust.mapper;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserGovernOrgMapper {

    List<Integer> selectUserGovernOrgByUserId(int userId);

    List<Integer> selectUserGovernOrgByOrgId(int orgId);

    void insertUserGovernOrg(@Param("userId") int userId, @Param("orgId") int orgId);

    void deleteUserGovernOrg(@Param("userId") int userId, @Param("orgId") int orgId);

    void deleteUserEnrollOrgByOrgId(int orgId);
}
