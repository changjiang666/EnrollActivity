package com.hust.mapper;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserCreateOrgMapper {


    void deleteUserCreateOrgByOrgId(int orgId);

    List<Integer> selectUserCreateOrgByUserId(int userId);

    List<Integer> selectUserCreateOrgByOrgId(int orgId);

    void insertUserCreateOrg(@Param("userId") int userId, @Param("orgId") int orgId);

    void updateCreator(@Param("userId") int userId, @Param("orgId") int orgId);
}
