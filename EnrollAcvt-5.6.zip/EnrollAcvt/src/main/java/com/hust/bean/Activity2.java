package com.hust.bean;


public class Activity2 {

    private int id;
    private int isName;
    private int isGender;
    private int isAge;
    private int isPhone;
    private int isCorporation;
    private int personLimit;

    public Activity2() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIsName() {
        return isName;
    }

    public void setIsName(int isName) {
        this.isName = isName;
    }

    public int getIsGender() {
        return isGender;
    }

    public void setIsGender(int isGender) {
        this.isGender = isGender;
    }

    public int getIsAge() {
        return isAge;
    }

    public void setIsAge(int isAge) {
        this.isAge = isAge;
    }

    public int getIsPhone() {
        return isPhone;
    }

    public void setIsPhone(int isPhone) {
        this.isPhone = isPhone;
    }

    public int getIsCorporation() {
        return isCorporation;
    }

    public void setIsCorporation(int isCorporation) {
        this.isCorporation = isCorporation;
    }

    public int getPersonLimit() {
        return personLimit;
    }

    public void setPersonLimit(int personLimit) {
        this.personLimit = personLimit;
    }

    @Override
    public String toString() {
        return "Activity2{" +
                "id=" + id +
                ", isName=" + isName +
                ", isGender=" + isGender +
                ", isAge=" + isAge +
                ", isPhone=" + isPhone +
                ", isCorporation=" + isCorporation +
                ", personLimit=" + personLimit +
                '}';
    }
}
