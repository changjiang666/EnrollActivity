package com.hust.bean;

import org.springframework.stereotype.Component;

/*DROP TABLE IF EXISTS `tbl_userGovernActivity`;
        CREATE TABLE `tbl_userGovernActivity` (
        `id` int(11) NOT NULL,
        `userId` int(11) NOT NULL,
        `governActivityId` int(11) NOT NULL,
        PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;*/
@Component("userGovernActivity")
public class UserGovernActivity {

    private int userId;
    private int governActivityId;

    public UserGovernActivity() {
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getGovernActivityId() {
        return governActivityId;
    }

    public void setGovernActivityId(int governActivityId) {
        this.governActivityId = governActivityId;
    }

    @Override
    public String toString() {
        return "UserGovernActivity{" +
                ", userId=" + userId +
                ", governActivityId=" + governActivityId +
                '}';
    }
}
