package com.hust.bean;


import org.springframework.stereotype.Component;

@Component("userConcernActivity")
public class UserConcernActivity {



    private int useId;
    private int concernActityId;

    public UserConcernActivity() {
    }

    public int getUseId() {
        return useId;
    }

    public void setUseId(int useId) {
        this.useId = useId;
    }

    public int getConcernActityId() {
        return concernActityId;
    }

    public void setConcernActityId(int concernActityId) {
        this.concernActityId = concernActityId;
    }

    @Override
    public String toString() {
        return "UserConcernActivity{" +
                ", useId=" + useId +
                ", concernActityId=" + concernActityId +
                '}';
    }
}
