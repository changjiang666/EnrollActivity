package com.hust.bean;


import org.springframework.stereotype.Component;


/*DROP TABLE IF EXISTS `tbl_userCreateOrg`;
        CREATE TABLE `tbl_userCreateOrg` (
        `id` int(11) NOT NULL,
        `userId` int(11) NOT NULL,
        `createOrgId` varchar(255) NOT NULL,
        PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;*/

@Component("userCreateOrg")
public class UserCreateOrg {

    private int userId;
    private int createOrgId;

    public UserCreateOrg() {
    }


    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getCreateOrgId() {
        return createOrgId;
    }

    public void setCreateOrgId(int createOrgId) {
        this.createOrgId = createOrgId;
    }

    @Override
    public String toString() {
        return "UserCreateOrg{" +
                ", userId=" + userId +
                ", createOrgId=" + createOrgId +
                '}';
    }
}
