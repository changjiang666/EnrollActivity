package com.hust.bean;

import org.springframework.stereotype.Component;

/*DROP TABLE IF EXISTS `tbl_userEnrollActivity`;
        CREATE TABLE `tbl_userEnrollActivity` (
        `id` int(11) NOT NULL,
        `userId` int(11) NOT NULL,
        `enrollActivityId` int(11) NOT NULL,
        `comment` varchar(255) NOT NULL,
        PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;*/

@Component("UserEnrollActivity")
public class UserEnrollActivity {

    private Integer userId;
    private Integer enrollActivityId;
    private String comment;
    private String commentImage;

    public UserEnrollActivity() {
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getEnrollActivityId() {
        return enrollActivityId;
    }

    public void setEnrollActivityId(Integer enrollActivityId) {
        this.enrollActivityId = enrollActivityId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getCommentImage() {
        return commentImage;
    }

    public void setCommentImage(String commentImage) {
        this.commentImage = commentImage;
    }

    @Override
    public String toString() {
        return "UserEnrollActivity{" +
                "userId=" + userId +
                ", enrollActivityId=" + enrollActivityId +
                ", comment='" + comment + '\'' +
                ", commentImage='" + commentImage + '\'' +
                '}';
    }
}
