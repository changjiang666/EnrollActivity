package com.hust.service;

import com.hust.bean.*;
import com.hust.mapper.*;
import com.hust.utilis.GetApplicationContext;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component("activity1Service")
public class Activity1Service {

    private static ApplicationContext ac;
    static  {
        ac = GetApplicationContext.getInstance();
    }

    public Map<String, Object> selectEnrollActivity(int id) {
        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        List<Activity1> list = mapper.selectEnrollActivity(id);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("activityList", list);
        return map;
    }

    public void insertActivity1(Activity1 activity1) {
        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        mapper.insertActivity1(activity1);
    }

    public Map<String, Object> selectAllById(int userId, int activityId) {

        Map<String, Object> map = new HashMap<String, Object>();
        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        Activity1 activity1 = mapper.selectActivityById(activityId);
        map.put("Activity1", activity1);

        UserEnrollActivityMapper userEnrollActivityMapper = ac.getBean(UserEnrollActivityMapper.class);


        UserMapper userMapper = ac.getBean(UserMapper.class);
        List<UserEnrollActivity> list = userEnrollActivityMapper.selectUserEnrollActivityById(activityId);
        List<Map<String, Object> > mapList = new ArrayList<Map<String, Object>>();
        for(UserEnrollActivity userEnrollActivity : list) {
            Map<String, Object> map1 = new HashMap<String, Object>();
            int uid = userEnrollActivity.getUserId();
            User user = userMapper.selectUserById(uid);
            map1.put("userId", uid);
            map1.put("activityId", activityId);
            map1.put("name", user.getName());
            map1.put("userHead", user.getAvatarUrl());
            map1.put("Comments", userEnrollActivity.getComment());
            map1.put("CommentImage", userEnrollActivity.getCommentImage());
            mapList.add(map1);
        }
        map.put("Comment", mapList);

        UserEnrollActivity userEnrollActivity = userEnrollActivityMapper.selectByUserIdAndActivityId(userId, activityId);
        Boolean isEnroll = true;
        if(userEnrollActivity == null)
            isEnroll = false;
        map.put("UserEnrollActivity", isEnroll);
        List<Integer> userIdList = userEnrollActivityMapper.selectUserIdByActivityId(activityId);


        UserConcernActivityMapper userConcernActivityMapper = ac.getBean(UserConcernActivityMapper.class);
        int cnt = userConcernActivityMapper.countAll(activityId);
        map.put("ConcernUserNum", cnt);

        Boolean isConcern = true;
        UserConcernActivity userConcernActivity = userConcernActivityMapper.selectByUserIdAndActivityID(userId, activityId);
        if(userConcernActivity == null)
            isConcern = false;
        map.put("UserConcernActivity", isConcern);


        UserGovernActivityMapper userGovernActivityMapper = ac.getBean(UserGovernActivityMapper.class);
        Boolean isGovern = true;
        UserGovernActivity userGovernActivity = userGovernActivityMapper.selectByUserIdAndActivityId(userId, activityId);
        if(userGovernActivity == null)
            isGovern = false;
        map.put("UserGovernActivity", isGovern);

        UserLaunchActivityMapper userLaunchActivityMapper = ac.getBean(UserLaunchActivityMapper.class);
        Boolean isLaunch = true;
        UserLaunchActivity userLaunchActivity = userLaunchActivityMapper.selectByUserIdAndActivityId(userId, activityId);
        if(userLaunchActivity == null)
            isLaunch = false;
        map.put("userLaunchActivity", isLaunch);



        if(isGovern || isLaunch)
            map.put("userIdList", userIdList);
        else
            map.put("userIdList", null);

        return map;
    }


    public void insertUserCreateActivity(Activity1 activity1, Activity2 activity2, int userId) {

        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        mapper.insertActivity1(activity1);
        activity2.setId(mapper.getActivityId());
        mapper.insertActivity2(activity2);

        UserLaunchActivityMapper userLaunchActivityMapper = ac.getBean(UserLaunchActivityMapper.class);
        userLaunchActivityMapper.userLaunchActivityMapper(userId, activity2.getId());
    }

    public void updateActivity(Activity1 activity1, Activity2 activity2, int userId) {

        UserLaunchActivityMapper userLaunchActivityMapper = ac.getBean(UserLaunchActivityMapper.class);
        int activityId = userLaunchActivityMapper.selectActivityIdByUserID(userId);
        activity1.setId(activityId);
        activity2.setId(activityId);

        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        mapper.updateActivity1(activity1);
        mapper.updateActivity2(activity2);
    }

    public List<Activity1> selectActivityListByIdList(List<Integer> activityIdList) {

        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        return mapper.selectActivityListByIdList(activityIdList);
    }

    public void deleteActivity1(int activityId) {

        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        mapper.deleteActivity1(activityId);
    }

    public void deleteActivity2(int activityId) {

        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        mapper.deleteActivity2(activityId);
    }

    public List<Activity1> getTypeById() {

        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        return mapper.getAll();
    }

    public Activity2 selectActivity2ById(int activityId) {

        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        return mapper.selectActivity2ById(activityId);
    }

    public List<Activity1> selectOrgCreateOrgByOrgId(int orgId) {

        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        return mapper.selectOrgCreateOrgByOrgId(orgId);
    }

    public List<Activity1> selectAllActivity() {

        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        return mapper.selectAllActivity();
    }

    public List<Activity1> selectActivityByOrgId(int orgId) {
        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        return mapper.selectActivityByOrgId(orgId);
    }

    public Organization selectAllOrgByActivityId(int activityId) {

        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        return mapper.selectAllOrgByActivityId(activityId);
    }

    public void updateCurrentPersonNum() {

        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        mapper.updateCurrentPersonNum();
    }

    public void updateCurrentPersonNum1() {

        Activity1Mapper mapper = ac.getBean(Activity1Mapper.class);
        mapper.updateCurrentPersonNum1();
    }
}
