package com.hust.service;


import com.hust.mapper.UserLaunchActivityMapper;
import com.hust.utilis.GetApplicationContext;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("userLaunchActivityService")
public class UserLaunchActivityService {

    private static ApplicationContext ac;
    static  {
        ac = GetApplicationContext.getInstance();
    }


    public void deleteRecordByActivityId(int activityId) {

        UserLaunchActivityMapper mapper = ac.getBean(UserLaunchActivityMapper.class);
        mapper.deleteRecordByActivityId(activityId);
    }

    public List<Integer> selectUserLaunchActivityById(int userId) {

        UserLaunchActivityMapper mapper = ac.getBean(UserLaunchActivityMapper.class);
        return mapper.selectUserLaunchActivityById(userId);
    }

    public List<Integer> selectUserLaunchActivityByActivityId(int activityId) {

        UserLaunchActivityMapper mapper = ac.getBean(UserLaunchActivityMapper.class);
        return mapper.selectUserLaunchActivityByActivityId(activityId);
    }
}
