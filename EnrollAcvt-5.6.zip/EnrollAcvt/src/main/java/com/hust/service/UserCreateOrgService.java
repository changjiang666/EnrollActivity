package com.hust.service;


import com.hust.mapper.UserCreateOrgMapper;
import com.hust.mapper.UserEnrollOrgMapper;
import com.hust.utilis.GetApplicationContext;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("userCreateOrgService")
public class UserCreateOrgService {

    private static ApplicationContext ac;
    static  {
        ac = GetApplicationContext.getInstance();
    }


    public void deleteUserCreateOrgByOrgId(int orgId) {

        UserCreateOrgMapper mapper = ac.getBean(UserCreateOrgMapper.class);
        mapper.deleteUserCreateOrgByOrgId(orgId);

    }

    public List<Integer> selectUserCreateOrgByUserId(int userId) {

        UserCreateOrgMapper userCreateOrgMapper = ac.getBean(UserCreateOrgMapper.class);
        return userCreateOrgMapper.selectUserCreateOrgByUserId(userId);
    }

    public List<Integer> selectUserCreateOrgByOrgId(int orgId) {
        UserCreateOrgMapper userCreateOrgMapper = ac.getBean(UserCreateOrgMapper.class);
        return userCreateOrgMapper.selectUserCreateOrgByOrgId(orgId);
    }

    public void insertUserCreateOrg(int userId, int orgId) {
        UserCreateOrgMapper userCreateOrgMapper = ac.getBean(UserCreateOrgMapper.class);
        userCreateOrgMapper.insertUserCreateOrg(userId, orgId);
    }

    public void updateCreator(int creatorId, int orgId) {

        UserCreateOrgMapper userCreateOrgMapper = ac.getBean(UserCreateOrgMapper.class);
        userCreateOrgMapper.updateCreator(creatorId, orgId);
    }
}
