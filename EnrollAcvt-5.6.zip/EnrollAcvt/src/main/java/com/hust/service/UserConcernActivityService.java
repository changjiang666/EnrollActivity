package com.hust.service;

import com.hust.bean.UserConcernActivity;
import com.hust.mapper.UserConcernActivityMapper;
import com.hust.utilis.GetApplicationContext;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("userConcernActivityService")
public class UserConcernActivityService {

    private static ApplicationContext ac;
    static  {
        ac = GetApplicationContext.getInstance();
    }

    public void updateConcern(int userId, int activityId) {
        UserConcernActivityMapper mapper = ac.getBean(UserConcernActivityMapper.class);
        UserConcernActivity userConcernActivity = mapper.selectByUserIdAndActivityID(userId, activityId);
        if(userConcernActivity == null)
            mapper.insertUserConcernActivity(userId, activityId);
        else
            mapper.delectUserConcernActivity(userId, activityId);
    }

    public List<Integer> selectUserConcernActivity(int userId) {

        UserConcernActivityMapper mapper = ac.getBean(UserConcernActivityMapper.class);
        return mapper.selectUserConcernActivity(userId);
    }

    public void deleteRecordByActivityId(int activityId) {

        UserConcernActivityMapper mapper = ac.getBean(UserConcernActivityMapper.class);
        mapper.deleteRecordByActivityId(activityId);
    }

    public List<Integer> selectUserConcernActivityByActivityId(int activityId) {

        UserConcernActivityMapper mapper = ac.getBean(UserConcernActivityMapper.class);
        return mapper.selectUserConcernActivityByActivityId(activityId);
    }
}
