package com.hust.service;

import com.hust.mapper.UserEnrollActivityMapper;
import com.hust.utilis.GetApplicationContext;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("userEnrollActivityService")
public class UserEnrollActivityService {

    private static ApplicationContext ac;
    static  {
        ac = GetApplicationContext.getInstance();
    }


    public void deleteRecordByActivityId(int activityId) {

        UserEnrollActivityMapper mapper = ac.getBean(UserEnrollActivityMapper.class);
        mapper.deleteRecordByActivityId(activityId);
    }

    public void InsertUserEnrollActivity(int userId, int activityId) {

        UserEnrollActivityMapper mapper = ac.getBean(UserEnrollActivityMapper.class);
        mapper.InsertUserEnrollActivity(userId, activityId);
    }

    public void deleteUserEnrollActivity(int userId, int activityId) {

        UserEnrollActivityMapper mapper = ac.getBean(UserEnrollActivityMapper.class);
        mapper.deleteUserEnrollActivity(userId, activityId);
    }

    public List<Integer> selectUserEnrollActivityByUserId(int userId) {

        UserEnrollActivityMapper mapper = ac.getBean(UserEnrollActivityMapper.class);
        return mapper.selectUserEnrollActivityByUserId(userId);
    }

    public void deleteCommentById(int userId, int activityId) {

        UserEnrollActivityMapper mapper = ac.getBean(UserEnrollActivityMapper.class);
        mapper.deleteCommentById(userId, activityId);
    }

    public List<Integer> selectUserEnrollActivityByActivityId(int activityId) {

        UserEnrollActivityMapper mapper = ac.getBean(UserEnrollActivityMapper.class);
        return mapper.selectUserIdByActivityId(activityId);
    }
}
